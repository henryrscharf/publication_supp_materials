## generate data ----
set.seed(1)
n <- 200
x <- runif(n, min = -3, max = 3)
beta <- 0.7
beta0 <- -1.7
mu_1 <- exp(x * beta) + beta0
sigma <- 1
z_1 <- rnorm(n, mean = mu_1, sd = sigma)
y_1 <- z_1 > 0
##
F_inv <- function(p, beta0, beta){
  -log(qnorm(p) - beta0) / beta
}
draw <- F_inv(runif(n * 2), beta0, beta)
draw <- draw[!is.na(draw)][1:n]
mu_2 <- x
z_2 <- mu_2 + draw
y_2 <- z_2 > 0
## plot ----
colors <- RColorBrewer::brewer.pal(n = 3, name = "Dark2")
quantiles <- seq(0.05, 0.95, l=19)
layout(matrix(1:4, 1, 4))
par(mar = c(4.1, 4.1, 0.1, 0.1))
ylim <- range(z_1, z_2)
plot(x, z_1, ylab = "z", type = "n", ylim = ylim)
for(p in quantiles){
  lines(sort(x), mu_1[order(x)] + qnorm(p), col = "lightgray")
}
lines(sort(x), mu_1[order(x)], lwd = 2.5)
points(x, z_1, col = colors[1])
par(mar = c(4.1, 3.1, 0.1, 1.1))
plot(x, z_2, type = "n", ylim = ylim, ylab = "z", yaxt = "n")
for(p in quantiles){
  lines(sort(x), mu_2[order(x)] + F_inv(p, beta0, beta), col = "lightgray")
}
lines(sort(x), mu_2[order(x)], lwd = 2.5)
points(x, z_2, col = colors[2])
par(mar = c(4.1, 4.1, 0.1, 0.1))
plot(sort(x), pnorm(mu_1[order(x)]),
     ylab = "probability", col = 1, type = "l", lwd = 2.5, ylim = c(-0.05, 1.05), xlab = "x")
points(x, (z_1 > 0) * 1.12 - 0.06, col = colors[1])
points(x, (z_2 > 0) * 1.05 - 0.025, col = colors[2])
plot(sort(x), dnorm(mu_1[order(x)]) * exp(sort(x) * beta) * beta,
     ylab = "probability", col = 1, type = "l", lwd = 2.5, ylim = c(-0.05, 1.05), xlab = "x")
## generate data ----
set.seed(2018)
beta <- 1
gamma0 <- 0.8
gamma <- beta * 0.25
sigma_1 <- x * gamma + gamma0
mu_1 <- x * beta
z_1 <- mu_1 + sigma_1 * rnorm(n = n)
##
F_inv <- function(p, gamma0, gamma, beta){
 -qnorm(p) * gamma0 / (beta - qnorm(p) * gamma)
}
draw <- F_inv(runif(n * 2), gamma0, gamma, beta)
draw <- draw[!is.na(draw)][1:n]
mu_2 <- x
z_2 <- mu_2 + draw
y_2 <- z_2 > 0
X_quantiles_qr <- function(quantile){
  inv_ps <- qnorm(p = quantile)
  inv_ps * gamma0 / (beta - inv_ps * gamma)
}
## device ----
pdf(file = "../fig/two_equiv_QR.pdf", height = 2.5, width = 8.5)
## plot ----
quantile_colors <- function(n_quantiles){
  # colorRampPalette(RColorBrewer::brewer.pal(n = 11, name = "BrBG")[-c(5:7)])(n_quantiles)
  colorRampPalette(RSciVisColor::scivis.pal(name = "dark_5"))(n_quantiles)
}
quantile.cex <- 2
colors <- rep("gray", 2)
cexs = c(0.7, 0.7)
n_quantiles <- 9
quantiles <- seq(1 / (n_quantiles + 1), n_quantiles / (n_quantiles + 1), l = n_quantiles)
label_offset <- 0.075
layout(matrix(c(1:4), 1, 4))
par(mar = c(4.1, 4.1, 1.6, 0.1))
ylim <- quantile(c(z_1, z_2), c(0.001, 0.999))
plot(x, z_1, ylab = "z", type = "n", ylim = ylim)
points(x, z_1, col = colors[1], cex = cexs[1])
for(p in quantiles){
  lines(sort(x), mu_1[order(x)] + qnorm(p, sd = sigma_1[order(x)]), col = "lightgray")
}
points(X_quantiles_qr(quantiles), rep(0, n_quantiles), pch = 16,
       cex = quantile.cex, col = quantile_colors(n_quantiles))
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(a)", xpd = T, cex = 1.5)
# lines(sort(x), mu_1[order(x)], lwd = 2.5)
par(mar = c(4.1, 3.1, 1.6, 1.1))
plot(x, z_2, type = "n", ylim = ylim, ylab = "z", yaxt = "n")
points(x, z_2, col = colors[2], pch = 2, cex = cexs[2])
for(p in quantiles){
  lines(sort(x), mu_2[order(x)] + F_inv(p, gamma0, gamma, beta), col = "lightgray")
}
points(X_quantiles_qr(quantiles), rep(0, n_quantiles), pch = 16,
       cex = quantile.cex, col = quantile_colors(n_quantiles))
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(b)", xpd = T, cex = 1.5)
# lines(sort(x), mu_2[order(x)], lwd = 2.5)
par(mar = c(4.1, 4.1, 1.6, 0.1))
plot(sort(x), pnorm((mu_1 / sigma_1)[order(x)]),
     ylab = "probability", col = 1, type = "l", lwd = 2.5, ylim = c(-0.05, 1.05), xlab = "x")
points(X_quantiles_qr(quantiles), quantiles, pch = 16,
       col = quantile_colors(n_quantiles), cex = quantile.cex)
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(c)", xpd = T, cex = 1.5)
# points(x, (z_1 > 0) * 1.12 - 0.06, col = colors[1], cex = cexs[1])
# points(x, (z_2 > 0) * 1.05 - 0.025, col = colors[2], pch = 2, cex = cexs[2])
legend("right", pch = 16, col = rev(quantile_colors(n_quantiles)),
       legend = rev(round(quantiles, 2)), bty = "n")
plot((sort(x)[-1] + sort(x)[-length(x)]) / 2,
     diff(pnorm((mu_1 / sigma_1)[order(x)])) / diff(sort(x)),
     ylab = expression(nabla*p), col = 1, type = "l", lwd = 2.5, ylim = c(-0.05, 1.05), xlab = "x")
points(X_quantiles_qr(quantiles),
       dnorm(X_quantiles_qr(quantiles) * beta /
               (X_quantiles_qr(quantiles) * gamma + gamma0)) *
         (beta / (X_quantiles_qr(quantiles) * gamma + gamma0) -
            X_quantiles_qr(quantiles) * beta * gamma /
            (X_quantiles_qr(quantiles) * gamma + gamma0)^2),
       pch = 16, col = quantile_colors(n_quantiles), cex = quantile.cex)
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(d)", xpd = T, cex = 1.5)
## dev.off ----
dev.off()
## ----
## BQR 2 dimensions ----
## generate data ----
set.seed(2018)
n <- 500
X <- cbind(1, runif(n, -3, 3), runif(n, -3, 3))
beta <- c(0, 0.5, 0.7)
# gamma0 <- 0.8
# gamma <- beta * 0.25
# sigma_1 <- x * gamma + gamma0
sigma_1 <- 1
mu_1 <- X %*% beta
z_1 <- mu_1 + sigma_1 * rnorm(n = n)
##
# F_inv <- function(p, gamma0, gamma, beta){
#   -qnorm(p) * gamma0 / (beta - qnorm(p) * gamma)
# }
# draw <- F_inv(runif(n * 2), gamma0, gamma, beta)
# draw <- draw[!is.na(draw)][1:n]
# mu_2 <- x
# z_2 <- mu_2 + draw
# y_2 <- z_2 > 0
# X_quantiles_qr <- function(quantile){
#   inv_ps <- qnorm(p = quantile)
#   inv_ps * gamma0 / (beta - inv_ps * gamma)
# }
# quantile_colors <- function(n_quantiles){
#   colorRampPalette(RColorBrewer::brewer.pal(n = 11, name = "BrBG")[-c(5:7)])(n_quantiles)
# }
get_X <- function(beta, sigma_1, p, x1_lim = c(-3, 3), n = 1e2, x_1 = NULL){
  if(is.null(x_1)){
    x_1 <- seq(x1_lim[1], x1_lim[2], l = n)
  }
  x_2 <- (qnorm(p) - beta[1] - beta[2] * x_1) / beta[3]
  return(cbind(x_1, x_2))
}
## device ----
pdf(file = "../fig/two_equiv_QR_MV.pdf", height = 2.5, width = 8.5 * 0.75)
## plot ----
label_offset_y <- -0.045
label_offset_x <- -0.045
layout(matrix(1:3, 1, 3))
grid_1 <- grid_2 <- seq(-3, 3, l = 2e1)
grid <- expand.grid(grid_1, grid_2)
prob_grid <- matrix(pnorm(cbind(1, as.matrix(grid)) %*% beta), length(grid_1), length(grid_2))
par(mar = c(0, 0.7, 0, 0))
##
pmat <- persp(grid_1, grid_2, matrix(0, length(grid_1), length(grid_2)),
              zlim = c(0, 1), theta = 45, phi = 25, border = NA,
              xlab = "", ylab = "", zlab = "")
text(-0.43, 0, labels = expression(z))
text(-0.23, -0.4, labels = expression(x[1]))
text(0.23, -0.4, labels = expression(x[2]))
for(p in rev(quantiles)){
  X_p <- get_X(beta = beta, sigma_1 = sigma_1, p = p)
  X_p <- X_p[X_p[, 1] > -3 & X_p[, 1] < 3 &
               X_p[, 2] > -3 & X_p[, 2] < 3, ]
  lines(trans3d(X_p[, 1], X_p[, 2], rep(0, nrow(X_p)), pmat = pmat), col = q_cols[which(p == quantiles)], lwd = 2)
  x_lim_star <- rbind(get_X(beta = beta, sigma_1 = sigma_1, p = p, x_1 = c(-3, 3)),
                      get_X(beta = beta[c(1, 3, 2)], sigma_1 = sigma_1, p = p, x_1 = c(-3, 3))[, 2:1])
  x_lims <- x_lim_star[x_lim_star[, 1] >= -3 & x_lim_star[, 1] <= 3 &
                         x_lim_star[, 2] >= -3 & x_lim_star[, 2] <= 3, ]
  alpha1 <- 0.1
  alpha2 <- -alpha1 * diff(x_lims[, 1]) / diff(x_lims[, 2])
  alpha0 <- -c(alpha1, alpha2) %*% x_lims[1, ]
  alpha <- c(alpha0, alpha1, alpha2)
  ##
  sides <- c(1 * (3 %in% x_lims[, 2]),
             2 * (3 %in% x_lims[, 1]),
             3 * (-3 %in% x_lims[, 2]),
             4 * (-3 %in% x_lims[, 1]))
  ##
  if(1 %in% sides){
    line_xs <- cbind(c(min(x_lims[, 1]), 3 * sign(alpha1)), 3)
    line <- cbind(line_xs, cbind(1, line_xs) %*% alpha)
    lines(trans3d(line[, 1], line[, 2], line[, 3], pmat = pmat), col = scales::alpha(q_cols[which(p == quantiles)], 0.3), lwd = 2)
  }
  if(2 %in% sides){
    line_xs <- cbind(max(x_lims[, 1]), c(min(x_lims[, 2]), 3 * sign(alpha1)))
    line <- cbind(line_xs, cbind(1, line_xs) %*% alpha)
    lines(trans3d(line[, 1], line[, 2], line[, 3], pmat = pmat), col = scales::alpha(q_cols[which(p == quantiles)], 0.3), lwd = 2)
  }
  if(3 %in% sides){
    line_xs <- cbind(c(max(x_lims[, 1]), 3 * sign(alpha1)), c(-3, 3))
    line <- cbind(line_xs, cbind(1, line_xs) %*% alpha)
    lines(trans3d(line[, 1], line[, 2], line[, 3], pmat = pmat), col = scales::alpha(q_cols[which(p == quantiles)], 0.3), lwd = 2)
  }
  if(4 %in% sides){
    line_xs <- cbind(min(x_lims[, 1]), c(max(x_lims[, 2]), 3 * sign(alpha1)))
    line <- cbind(line_xs, cbind(1, line_xs) %*% alpha)
    lines(trans3d(line[, 1], line[, 2], line[, 3], pmat = pmat), col = scales::alpha(q_cols[which(p == quantiles)], 0.3), lwd = 2)
    if(!(1 %in% sides)){
      line_xs <- cbind(c(-3, 3), 3)
      line <- cbind(line_xs, cbind(1, line_xs) %*% alpha)
      lines(trans3d(line[, 1], line[, 2], line[, 3], pmat = pmat), col = scales::alpha(q_cols[which(p == quantiles)], 0.3), lwd = 2)
    }
  }
}
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(a)", xpd = T, cex = 1.5)
##
pmat <- persp(grid_1, grid_2, prob_grid, theta = 45, phi = 25, border = "black",
              col = scales::alpha(1, 0.4),
              xlab = "", ylab = "", zlab = "probability", xpd = T)
text(-0.23, -0.4, labels = expression(x[1]))
text(0.23, -0.4, labels = expression(x[2]))
points(trans3d(X[, 2], X[, 3], z_1 > 0, pmat = pmat), pch = 1, cex = 0.7, col = "gray")
q_cols <- quantile_colors(length(quantiles))
for(p in quantiles){
  X_p <- get_X(beta = beta, sigma_1 = sigma_1, p = p)
  X_p <- X_p[X_p[, 1] > -3 & X_p[, 1] < 3 &
               X_p[, 2] > -3 & X_p[, 2] < 3, ]
  lines(trans3d(X_p[, 1], X_p[, 2], rep(p, nrow(X_p)), pmat = pmat), col = q_cols[which(p == quantiles)], lwd = 2)
}
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(b)", xpd = T, cex = 1.5)
##
density_grid <- matrix(sum(beta[2:3]) * dnorm(cbind(1, as.matrix(grid)) %*% beta),
                       length(grid_1), length(grid_2))
pmat <- persp(grid_1, grid_2, density_grid, theta = 45, phi = 25, border = "black",
              col = scales::alpha(1, 0.4), zlim = c(0, 1),
              xlab = "", ylab = "", zlab = "")
text(-0.46, 0, labels = expression("|"*nabla*p*"|"), xpd = T)
text(-0.23, -0.4, labels = expression(x[1]))
text(0.23, -0.4, labels = expression(x[2]))
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(c)", xpd = T, cex = 1.5)
## dev.off ----
dev.off()
