## generate ----
library(ald)
set.seed(1)
colors <- RColorBrewer::brewer.pal(n = 3, name = "Dark2")
quantiles <- seq(0.05, 0.95, l=7)
n <- 2e2
x <- runif(n) * 2 - 1
beta <- 3
sigma_1 <- 0.25
p_1 <- 0.25
mu_1 <- x * beta
z_1 <- mu_1 + sigma_1 * rALD(n = n, p = p_1)
##
sigma_2 <- 1
mu_2 <- sigma_2 * qnorm(1 - pALD(q = -mu_1, sigma = sigma_1, p = p_1))
z_2 <- mu_2 + rnorm(n = n, sd = sigma_2)
##
## device ----
pdf(file = "../fig/equiv_aux_var.pdf", height = 4.5, width = 8.5)
## plot ----
label_offset <- 0.085
layout(matrix(1:8, 2, 4, byrow = T))
par(mar = c(4.1, 4.1, 1.6, 0.1))
ylim <- range(z_1, z_2)
plot(x, z_1, ylab = "z", type = "n", ylim = ylim)
for(p in quantiles){
  lines(sort(x), mu_1[order(x)] + qALD(prob = p, p = p_1), col = "lightgray")
}
lines(sort(x), mu_1[order(x)], lwd = 2)
points(x, z_1, col = colors[1])
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(a)", xpd = T, cex = 1.5)
par(mar = c(4.1, 2.1, 1.6, 2.1))
plot(x, z_2, type = "n", ylim = ylim, ylab = "z", yaxt = "n")
for(p in quantiles){
  lines(sort(x), mu_2[order(x)] + qnorm(p), col = "lightgray")
}
lines(sort(x), mu_2[order(x)], lwd = 2)
points(x, z_2, col = colors[2])
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(b)", xpd = T, cex = 1.5)
par(mar = c(4.1, 3.6, 1.6, 0.6))
plot(sort(x), 1 - pALD(q = -mu_1[order(x)], sigma = sigma_1, p = p_1),
     ylab = "", col = 1, type = "l", lwd = 2, xpd = T,
     ylim = c(-0.05, 1.05), xlab = "x")
mtext("probability", 2, cex = 0.7, line = 2.7)
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(c)", xpd = T, cex = 1.5)
# points(x, (z_1 > 0) * 1.12 - 0.06, col = colors[1])
# points(x, (z_2 > 0) * 1.05 - 0.025, col = colors[2])
plot(sort(x), dALD(-mu_1[order(x)], sigma = sigma_1, p = p_1), ylim = c(0, 1),
     ylab = "", col = 1, type = "l", lwd = 2, xlab = "x")
mtext(expression(nabla[x]*p), 2, cex = 0.7, line = 2.7)
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(d)", xpd = T, cex = 1.5)
##
beta <- 1.5
sigma_3 <- x * beta * 0.15 + 0.25
p_3 <- 0.5
mu_3 <- x * beta
z_3 <- mu_3 + sigma_3 * rALD(n = n, p = p_3)
##
sigma_4 <- 1
mu_4 <- sigma_4 * qnorm(1 - sapply(1:n, function(i) pALD(q = -mu_3[i], sigma = sigma_3[i], p = p_3)))
z_4 <- mu_4 + rnorm(n = n) * sigma_4
##
ylim <- range(z_3, z_4)
ylim <- c(-7, 5)
par(mar = c(4.1, 4.1, 1.6, 0.1))
plot(x, z_3, ylab = "z", type = "n", ylim = ylim)
for(p in quantiles){
  lines(sort(x), mu_3[order(x)] +
          sapply(sigma_3[order(x)], function(s) qALD(prob = p, p = p_3, sigma = s)),
        col = "lightgray")
}
lines(sort(x), mu_3[order(x)], lwd = 2)
points(x, z_3, col = colors[1])
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(e)", xpd = T, cex = 1.5)
par(mar = c(4.1, 2.1, 1.6, 2.1))
plot(x, z_4, type = "n", ylim = ylim, ylab = "", yaxt = "n")
for(p in quantiles){
  lines(sort(x), mu_4[order(x)] + qnorm(p), col = "lightgray")
}
lines(sort(x), mu_4[order(x)], lwd = 2)
points(x, z_4, col = colors[2])
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(f)", xpd = T, cex = 1.5)
par(mar = c(4.1, 3.6, 1.6, 0.6))
plot(sort(x), 1 - sapply(order(x), function(i) pALD(q = -mu_3[i], sigma = sigma_3[i], p = p_3)),
     ylab = "", lwd = 2, type = "l", ylim = c(-0.05, 1.05), xlab = "x")
mtext("probability", 2, cex = 0.7, line = 2.7)
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(g)", xpd = T, cex = 1.5)
# points(x, (z_3 > 0) * 1.12 - 0.06, col = colors[1])
# points(x, (z_4 > 0) * 1.05 - 0.025, col = colors[2])
plot(sort(x), sapply(order(x), function(i) dALD(-mu_3[i], sigma = sigma_3[i], p = p_3)),
     ylab = "", lwd = 2, type = "l", xlab = "x", ylim = c(0, 1))
mtext(expression(nabla[x]*p), 2, cex = 0.7, line = 2.7)
text(par()$usr[1] - label_offset * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset * diff(par()$usr[3:4]), "(h)", xpd = T, cex = 1.5)
## dev.off ----
dev.off()

## ----
## generate ----
set.seed(1)
colors <- RColorBrewer::brewer.pal(n = 3, name = "Dark2")
n <- 2e2
x <- runif(n) * 2 - 1
beta <- 3
sigma_1 <- 1
mu_1 <- x * beta
sigma_2 <- 0.06
p_2 <- 0.1
mu_2 <- sigma_2 * qALD(prob = 1 - pnorm(q = -mu_1, sd = sigma_1), p = 1 - p_2)
p_3 <- 0.5
sigma_3 <- mu_1 * 0.05 + 0.15
mu_3 <- sigma_3 * qALD(prob = 1 - pnorm(q = -mu_1, sd = sigma_1), p = 1 - p_3)
## device ----
pdf(file = "../fig/equiv_aux_var2.pdf", height = 6, width = 8.5)
## plot ----
layout(matrix(1:6, 2, 3)); par(mar = c(4.1, 4.1, 1, 0), oma = c(0, 0, 1, 0))
plot(x, mu_1 + rnorm(n = n, sd = sigma_1), ylab = "z", col = colors[1])
ylim <- par()$usr[3:4]
lines(sort(x), mu_1[order(x)], lwd = 2)
plot(x, 1 - pnorm(q = -mu_1, sd = sigma_1), ylab = "probability", col = colors[1])
##
par(mar = c(4.1, 3, 1, 1.1))
plot(x, mu_2 + rALD(n = n, sigma = sigma_2, p = p_2), col = colors[2], ylim = ylim, yaxt = "n")
lines(sort(x), mu_2[order(x)], lwd = 2)
plot(x, 1 - pALD(q = -mu_2, sigma = sigma_2, p = p_2), col = colors[2], yaxt = "n")
##
par(mar = c(4.1, 1.1, 1, 3))
plot(x, mu_3 + sigma_3 * rALD(n = n, p = p_3), col = colors[3], ylim = ylim, yaxt = "n")
lines(sort(x), mu_3[order(x)], lwd = 2)
plot(x, 1 - sapply(1:n, function(i) pALD(q = -mu_3[i], sigma = sigma_3[i], p = p_3)),
     col = colors[3], yaxt = "n")
## dev.off ----
dev.off()
