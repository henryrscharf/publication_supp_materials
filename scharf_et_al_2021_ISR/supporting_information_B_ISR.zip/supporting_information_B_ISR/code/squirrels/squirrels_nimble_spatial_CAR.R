################# ----
## PRELIMINARY ## ----
################# ----
## libraries ----
library(nimble); library(Matrix); library(raster)
## squirrel data ----
squirrels <- read.table(file = "../data/squirrels/SwissSquirrels.txt", header = T)
load(file = "../data/squirrels/Switzerland.RData")
N <- nrow(squirrels)
J <- 3
# ## KR colors
# map_colors <- c("grey", "yellow", "orange", "red")
## my colors
map_colors <- RSciVisColor::scivis.pal("blue_orange_div")[-c(22:26)]
## nimble model code[N, P, KR, SP] ----
source("squirrels/nimble_models.R")
## data lists [N, L, Q] ----
source("squirrels/nimble_data_lists.R")
## create our spatial model objects [SPL\Q] ----
SPLconst_scaled <- SPLconstants
SPLconst_scaled$var_beta <- 10 * SPLconstants$var_beta
SPLconst_scaled$var_alpha <- 10 * SPLconstants$var_alpha
SPQconst_scaled <- SPQconstants
SPQconst_scaled$var_beta <- 0.5 * SPQconstants$var_beta
SPQconst_scaled$var_alpha <- 0.5 * SPQconstants$var_alpha
SPLmodel <- nimbleModel(code = SPcode, constants = SPLconst_scaled,
                        data = Ldata, inits = SPLinits, check = T)
SPLmcmcConf <- configureMCMC(SPLmodel)
SPLmcmcConf$addMonitors2('r', 'eta', 'p', 'lambda')
SPLmcmc <- buildMCMC(SPLmcmcConf)
##
SPQmodel <- nimbleModel(code = SPcode, constants = SPQconst_scaled,
                        data = Qdata, inits = SPQinits, check = T)
SPQmcmcConf <- configureMCMC(SPQmodel)
SPQmcmcConf$addMonitors2('r', 'eta', 'p', 'lambda')
SPQmcmc <- buildMCMC(SPQmcmcConf)
## compile objects [SPL\Q] ----
CSPLmodel <- compileNimble(SPLmodel)
CSPLmcmc <- compileNimble(SPLmcmc, project = SPLmodel)
##
CSPQmodel <- compileNimble(SPQmodel)
CSPQmcmc <- compileNimble(SPQmcmc, project = SPQmodel)
## N_iterations + fit ----
N_iterations <- 5e4
system.time({
  CSPLmcmc$run(N_iterations, nburnin = N_iterations / 2)
})
SPLsamples <- as.matrix(CSPLmcmc$mvSamples)
SPLsamples2 <- as.matrix(CSPLmcmc$mvSamples2)
SPLsamples_transformed <- SPLsamples %*% Matrix::bdiag(t(L_A_alpha), t(L_A_beta), 1)
colnames(SPLsamples_transformed) <- colnames(SPLsamples)
##
system.time({
  CSPQmcmc$run(N_iterations, nburnin = N_iterations / 2)
})
SPQsamples <- as.matrix(CSPQmcmc$mvSamples)
SPQsamples2 <- as.matrix(CSPQmcmc$mvSamples2)
SPQsamples_transformed <- SPQsamples %*% Matrix::bdiag(t(Q_A_alpha), t(Q_A_beta), 1)
colnames(SPQsamples_transformed) <- colnames(SPQsamples)
## save chains ----
save(SPLsamples_transformed, SPLsamples, SPLsamples2,
     SPQsamples_transformed, SPQsamples, SPQsamples2, file = "../data/squirrels/SP_fit.RData")
## load chains ----
load(file = "../data/squirrels/SP_fit.RData")
## ----
## device ----
pdf(file = "../fig/squirrels_diagnostics_SP.pdf", width = 8, height = 7)
## plot traces [SPL] ----
used_iterations <- seq(N_iterations / 2 + 1, N_iterations, 1)
layout(matrix(1:3, 3, 1))
matplot(used_iterations, SPLsamples[, grep('beta', colnames(SPLsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(beta[svd]), xlab = "")
abline(h = 0, lty = 2)
matplot(used_iterations, SPLsamples[, grep('alpha', colnames(SPLsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(alpha[svd]), xlab = "")
abline(h = 0, lty = 2)
matplot(used_iterations, SPLsamples[, grep('tau', colnames(SPLsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(tau), xlab = "")
## plot traces [SPQ] ----
used_iterations <- seq(N_iterations / 2 + 1, N_iterations, 1)
layout(matrix(1:3, 3, 1))
matplot(used_iterations, SPQsamples[, grep('beta', colnames(SPQsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(beta[svd]), xlab = "")
abline(h = 0, lty = 2)
matplot(used_iterations, SPQsamples[, grep('alpha', colnames(SPQsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(alpha[svd]), xlab = "")
abline(h = 0, lty = 2)
matplot(used_iterations, SPLsamples[, grep('tau', colnames(SPLsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(tau), xlab = "")
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_effects_SPL.pdf", width = 8, height = 7)
## calc effects [SPL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- exp(X_elevation %*% t(SPLsamples_transformed[, grep('beta', colnames(SPLsamples_transformed))]))
pr_elevation <- t(apply(1 - exp(-lambda_elevation_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- exp(X_forest %*% t(SPLsamples_transformed[, grep('beta', colnames(SPLsamples_transformed))]))
pr_forest <- t(apply(1 - exp(-lambda_forest_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
probit_pr_date_iter <- X_date %*% t(SPLsamples_transformed[, grep('alpha', colnames(SPLsamples_transformed))])
pr_date <- t(apply(pnorm(as.matrix(probit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
probit_pr_duration_iter <- X_duration %*% t(SPLsamples_transformed[, grep('alpha', colnames(SPLsamples_transformed))])
pr_duration <- t(apply(pnorm(as.matrix(probit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## plot effects [SPL] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values, pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1, las = 1,
        ylab = "Pred. occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values, pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1,
        ylab = "Pred. occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values, pr_date, type = "l", lty = 1, col = line_colors,
        lwd = lwds, ylim = 0:1,
        ylab = "Pred. detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values, pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1,
        ylab = "Pred. detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curves - SPL", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_grad_effects_SPL.pdf", width = 8, height = 7)
## calc grad effects [SPL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- exp(X_elevation %*% t(SPLsamples_transformed[, grep('beta', colnames(SPLsamples_transformed))]))
grad_pr_elevation <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    (SPLsamples_transformed[, grep('beta\\[2\\]', colnames(SPLsamples_transformed))]),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- exp(X_forest %*% t(SPLsamples_transformed[, grep('beta', colnames(SPLsamples_transformed))]))
pr_forest_iter <- 1 - exp(-lambda_forest_iter)
grad_pr_forest <- t(apply(
  t(exp(-lambda_forest_iter) * lambda_forest_iter) *
    (SPLsamples_transformed[, grep('beta\\[3\\]', colnames(SPLsamples_transformed))]),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
probit_pr_date_iter <- X_date %*% t(SPLsamples_transformed[, grep('alpha', colnames(SPLsamples_transformed))])
grad_pr_date <- t(apply(
  t(dnorm(as.matrix(probit_pr_date_iter))) *
    SPLsamples_transformed[, grep('alpha\\[2\\]', colnames(SPLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
probit_pr_duration_iter <- X_duration %*% t(SPLsamples_transformed[, grep('alpha', colnames(SPLsamples_transformed))])
grad_pr_duration <- t(apply(
  t(dnorm(as.matrix(probit_pr_duration_iter))) *
    SPLsamples_transformed[, grep('alpha\\[3\\]', colnames(SPLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## plot grad effects [SPL] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values, 1e2 * grad_pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values, 10 * grad_pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values, 14 * grad_pr_date, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values, 60 * grad_pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curve gradients - SPL", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_effects_SPQ.pdf", width = 8, height = 7)
## calc effects [SPQ] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- exp(X_elevation %*% t(SPQsamples_transformed[, grep('beta', colnames(SPQsamples_transformed))]))
pr_elevation <- t(apply(1 - exp(-lambda_elevation_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- exp(X_forest %*% t(SPQsamples_transformed[, grep('beta', colnames(SPQsamples_transformed))]))
pr_forest <- t(apply(1 - exp(-lambda_forest_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
probit_pr_date_iter <- X_date %*% t(SPQsamples_transformed[, grep('alpha', colnames(SPQsamples_transformed))])
pr_date <- t(apply(pnorm(as.matrix(probit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
probit_pr_duration_iter <- X_duration %*% t(SPQsamples_transformed[, grep('alpha', colnames(SPQsamples_transformed))])
pr_duration <- t(apply(pnorm(as.matrix(probit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## plot effects [SPQ] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values, pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1, las = 1,
        ylab = "Pred. occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values, pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1,
        ylab = "Pred. occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values, pr_date, type = "l", lty = 1, col = line_colors,
        lwd = lwds, ylim = 0:1,
        ylab = "Pred. detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values, pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1,
        ylab = "Pred. detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curves - SPQ", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_grad_effects_SPQ.pdf", width = 8, height = 7)
## calc grad effects [SPQ] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- exp(X_elevation %*% t(SPQsamples_transformed[, grep('beta', colnames(SPQsamples_transformed))]))
grad_pr_elevation <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    (SPQsamples_transformed[, grep('beta\\[2\\]', colnames(SPQsamples_transformed))] +
       2 * t(elev_values %o% SPQsamples_transformed[, grep('beta\\[4\\]', colnames(SPQsamples_transformed))]) +
       forest_value * SPQsamples_transformed[, grep('beta\\[6\\]', colnames(SPQsamples_transformed))] +
       2 * forest_value * t(elev_values %o% SPQsamples_transformed[, grep('beta\\[7\\]', colnames(SPQsamples_transformed))]) +
       forest_value^2 * SPQsamples_transformed[, grep('beta\\[8\\]', colnames(SPQsamples_transformed))]),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- exp(X_forest %*% t(SPQsamples_transformed[, grep('beta', colnames(SPQsamples_transformed))]))
pr_forest_iter <- 1 - exp(-lambda_forest_iter)
grad_pr_forest <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    (SPQsamples_transformed[, grep('beta\\[3\\]', colnames(SPQsamples_transformed))] +
       2 * t(forest_values %o% SPQsamples_transformed[, grep('beta\\[5\\]', colnames(SPQsamples_transformed))]) +
       elev_value * SPQsamples_transformed[, grep('beta\\[6\\]', colnames(SPQsamples_transformed))] +
       elev_value^2 * SPQsamples_transformed[, grep('beta\\[7\\]', colnames(SPQsamples_transformed))] +
       2 * elev_value * t(forest_values %o% SPQsamples_transformed[, grep('beta\\[8\\]', colnames(SPQsamples_transformed))])),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
probit_pr_date_iter <- X_date %*% t(SPQsamples_transformed[, grep('alpha', colnames(SPQsamples_transformed))])
grad_pr_date <- t(apply(
  t(dnorm(as.matrix(probit_pr_date_iter))) *
    SPQsamples_transformed[, grep('alpha\\[2\\]', colnames(SPQsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
probit_pr_duration_iter <- X_duration %*% t(SPQsamples_transformed[, grep('alpha', colnames(SPQsamples_transformed))])
grad_pr_duration <- t(apply(
  t(dnorm(as.matrix(probit_pr_duration_iter))) *
    (SPQsamples_transformed[, grep('alpha\\[3\\]', colnames(SPQsamples_transformed))] +
       2 * t(dur_values %o% SPQsamples_transformed[, grep('alpha\\[4\\]', colnames(SPQsamples_transformed))])),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## plot grad effects [SPQ] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values, 1e2 * grad_pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values, 10 * grad_pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values, 14 * grad_pr_date, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values, 60 * grad_pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curve gradients - SPQ", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
## device ----
pdf("../fig/squirrels_map_lambda_SPL.pdf")
## summarize lambda + plot [SPL] ----
summary_lambda <- apply(SPLsamples2[, grep("\\<lambda", colnames(SPLsamples2))], 2, quantile, probs = c(0.025, 0.5, 0.975))
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
layout(matrix(c(2:4, 1, 1, 1), 2, 3, byrow = T))
par(mar = c(5, 5, 1, 1))
lambda_acf <- acf(SPLsamples2[, grep("\\<lambda", colnames(SPLsamples2))[1]], lag.max = 100, plot = T)
titles <- c("2.5%", "50%", "97.5%")
par(mar = c(1, 1, 1, 1))
for(summary in 1:3){
  sum_lambda <- summary_lambda[summary, ]
  log_sum_lambda <- log(sum_lambda + 1)
  colors <- rgb(colorRamp(map_colors)(
    (log_sum_lambda - min(log_sum_lambda)) / diff(range(log_sum_lambda))), maxColorValue = 255)
  plot(as.matrix(squirrels[, c('coordx', 'coordy')]), asp = 1,
       col = colors, axes = F, xlab = "", ylab = "",
       main = titles[summary], pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
  legend("bottom", horiz = T, pch = 15, cex = 1.5, col = c("grey", "red"), legend = round(range(sum_lambda), 4))
}
## dev.off ----
dev.off()
## ----
## device ----
pdf("../fig/squirrels_map_lambda_SPQ.pdf")
## summarize lambda + plot [SPQ] ----
summary_lambda <- apply(SPQsamples2[, grep("\\<lambda", colnames(SPQsamples2))], 2, quantile, probs = c(0.025, 0.5, 0.975))
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
layout(matrix(c(2:4, 1, 1, 1), 2, 3, byrow = T))
par(mar = c(5, 5, 1, 1))
lambda_acf <- acf(SPQsamples2[, grep("\\<lambda", colnames(SPQsamples2))[1]], lag.max = 100, plot = T)
titles <- c("2.5%", "50%", "97.5%")
par(mar = c(1, 1, 1, 1))
for(summary in 1:3){
  sum_lambda <- summary_lambda[summary, ]
  log_sum_lambda <- log(sum_lambda + 1)
  colors <- rgb(colorRamp(map_colors)(
    (log_sum_lambda - min(log_sum_lambda)) / diff(range(log_sum_lambda))), maxColorValue = 255)
  plot(as.matrix(squirrels[, c('coordx', 'coordy')]), asp = 1,
       col = colors, axes = F, xlab = "", ylab = "",
       main = titles[summary], pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
  legend("bottom", horiz = T, pch = 15, cex = 1.5, col = c("grey", "red"), legend = round(range(sum_lambda), 4))
}
## dev.off ----
dev.off()
## ----
## device ----
pdf("../fig/squirrels_map_eta_SPL.pdf")
## summarize eta + plot [SPL] ----
summary_eta <- apply(SPLsamples2[, grep("\\<eta", colnames(SPLsamples2))], 2, quantile, probs = c(0.025, 0.5, 0.975))
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
layout(matrix(c(2:4, 1, 1, 1), 2, 3, byrow = T))
par(mar = c(5, 5, 1, 1))
eta_acf <- acf(SPLsamples2[, grep("\\<eta", colnames(SPLsamples2))[1]], lag.max = 100, plot = T)
titles <- c("2.5%", "50%", "97.5%")
par(mar = c(1, 1, 1, 1))
for(summary in 1:3){
  sum_eta <- summary_eta[summary, ]
  plot(squirrels[, c('coordx', 'coordy')], asp = 1,
       col = rgb(colorRamp(map_colors)(
         (sum_eta - min(sum_eta)) / diff(range(sum_eta))), maxColorValue = 255),
       axes = F, xlab = "", ylab = "", main = titles[summary], pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
  legend("bottom", horiz = T, pch = 15, cex = 1.5, col = c("grey", "red"), legend = round(range(sum_eta), 4))
}
## dev.off ----
dev.off()

## ----
## device ----
pdf("../fig/squirrels_map_eta_SPQ.pdf")
## summarize eta + plot [SPQ] ----
summary_eta <- apply(SPQsamples2[, grep("\\<eta", colnames(SPQsamples2))], 2, quantile, probs = c(0.025, 0.5, 0.975))
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
layout(matrix(c(2:4, 1, 1, 1), 2, 3, byrow = T))
par(mar = c(5, 5, 1, 1))
eta_acf <- acf(SPQsamples2[, grep("\\<eta", colnames(SPQsamples2))[1]], lag.max = 100, plot = T)
titles <- c("2.5%", "50%", "97.5%")
par(mar = c(1, 1, 1, 1))
col_ramp <- colorRamp(map_colors)
for(summary in 1:3){
  sum_eta <- summary_eta[summary, ]
  plot(squirrels[, c('coordx', 'coordy')], asp = 1,
       col = rgb(col_ramp((sum_eta - min(summary_eta)) / diff(range(summary_eta))), maxColorValue = 255),
       axes = F, xlab = "", ylab = "", main = titles[summary], pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
  legend("bottom", horiz = T, pch = 15, cex = 1.5, legend = round(range(sum_eta), 2), bty = "n",
         col = rgb(col_ramp((range(sum_eta) - min(summary_eta)) / diff(range(summary_eta))), maxColorValue = 255))
}
## dev.off ----
dev.off()
## ----
## device ----
pdf("../fig/squirrels_map_eta_SPL_SPQ.pdf", width = 8, height = 4)
## layout  ----
layout(matrix(1:6, 2, 3, byrow = T))
par(mar = c(0.5, 0.5, 0.5, 0.5), oma = c(4, 3, 0, 0))
titles <- c("2.5%", "50%", "97.5%")
col_ramp <- colorRamp(map_colors)
# range_eta <- range(pretty(c(apply(SPLsamples2[, grep("\\<eta", colnames(SPLsamples2))], 2, quantile, probs = c(0.025, 0.5, 0.975)),
#                              apply(SPQsamples2[, grep("\\<eta", colnames(SPQsamples2))], 2, quantile, probs = c(0.025, 0.5, 0.975)))))
range_eta <- c(-6, 6)
legend_values <- c(-5, -3, -1, 1, 3, 5)
## plot eta SPL ----
summary_eta <- apply(SPLsamples2[, grep("\\<eta", colnames(SPLsamples2))], 2, quantile, probs = c(0.025, 0.5, 0.975))
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
for(summary in 1:3){
  sum_eta <- summary_eta[summary, ]
  plot(squirrels[, c('coordx', 'coordy')], asp = 1,
       col = rgb(col_ramp((sum_eta - range_eta[1]) / diff(range_eta)), maxColorValue = 255),
       axes = F, xlab = "", ylab = "", main = "", pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
  # legend("bottom", horiz = T, pch = 15, cex = 1.5, legend = round(range(sum_eta), 2), bty = "n",
  #        col = rgb(col_ramp((range(sum_eta) - range_eta[1]) / diff(range_eta)), maxColorValue = 255))
  if(summary == 1){
    mtext("SPL", 2, 2)
  }
}
## plot eta SPQ ----
summary_eta <- apply(SPQsamples2[, grep("\\<eta", colnames(SPQsamples2))], 2, quantile, probs = c(0.025, 0.5, 0.975))
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
for(summary in 1:3){
  sum_eta <- summary_eta[summary, ]
  plot(squirrels[, c('coordx', 'coordy')], asp = 1,
       col = rgb(col_ramp((sum_eta - range_eta[1]) / diff(range_eta)), maxColorValue = 255),
       axes = F, xlab = "", ylab = "", main = "", pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
  if(summary == 2){
    legend(x = mean(par()$usr[1:2]), y = c(0.95, 0.05) %*% par()$usr[3:4],
           xjust = 0.5, horiz = T, pch = 15, cex = 1.5,
           legend = legend_values, bty = "n", xpd = NA, x.intersp = 0.7,
           col = rgb(col_ramp((legend_values - range_eta[1]) / diff(range_eta)), maxColorValue = 255))
  }
  if(summary == 1){
    mtext("SPQ", 2, 2)
  }
  mtext(titles[summary], 1, 3)
}
## title ----
# title(main = "Spatial random effect", outer = T, cex.main = 2, line = -0.4)
## dev.off ----
dev.off()
## ----
## device ----
pdf("../fig/squirrels_map_p_SPL.pdf")
## rasterize p + plot [SPL] ----
median_p <- matrix(apply(SPLsamples2[, grep("\\<p", colnames(SPLsamples2))], 2, median), ncol = 3)
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
layout(matrix(1:9, 3, 3, byrow = T))
for(visit in 1:3){
  plot(squirrels[, c('coordx', 'coordy')], asp = 1,
       col = rgb(colorRamp(map_colors)(median_p[, visit]), maxColorValue = 255),
       axes = F, xlab = "", ylab = paste0("visit", visit), main = "p",pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
  data_visit <- squirrels[, paste0('det07', visit)]
  plot(squirrels[!is.na(data_visit), c('coordx', 'coordy')], asp = 1,
       col = rgb(colorRamp(map_colors)(data_visit[!is.na(data_visit)]), maxColorValue = 255),
       axes = F, xlab = "", ylab = "", main = "data", pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
  plot(squirrels[, c('coordx', 'coordy')], asp = 1, type = "n",
       axes = F, xlab = "", ylab = "", main = "|p - y| > 0.5")
  points(squirrels[((median_p[, visit] - data_visit) < -0.5)[!is.na(data_visit)], c('coordx', 'coordy')],
       col = "red", pch = 15, cex = 1.5)
  points(squirrels[((median_p[, visit] - data_visit) > 0.5)[!is.na(data_visit)], c('coordx', 'coordy')],
       col = "blue", pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
}
## dev.off ----
dev.off()

## ----
## device ----
pdf("../fig/squirrels_map_p_SPQ.pdf")
## rasterize p + plot [SPQ] ----
median_p <- matrix(apply(SPQsamples2[, grep("\\<p", colnames(SPQsamples2))], 2, median), ncol = 3)
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
layout(matrix(1:9, 3, 3, byrow = T))
for(visit in 1:3){
  plot(squirrels[, c('coordx', 'coordy')], asp = 1,
       col = rgb(colorRamp(map_colors)(median_p[, visit]), maxColorValue = 255),
       axes = F, xlab = "", ylab = paste0("visit", visit), main = "p",pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
  data_visit <- squirrels[, paste0('det07', visit)]
  plot(squirrels[!is.na(data_visit), c('coordx', 'coordy')], asp = 1,
       col = rgb(colorRamp(map_colors)(data_visit[!is.na(data_visit)]), maxColorValue = 255),
       axes = F, xlab = "", ylab = "", main = "data", pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
  plot(squirrels[, c('coordx', 'coordy')], asp = 1, type = "n",
       axes = F, xlab = "", ylab = "", main = "|p - y| > 0.5")
  points(squirrels[((median_p[, visit] - data_visit) < -0.5)[!is.na(data_visit)], c('coordx', 'coordy')],
         col = "red", pch = 15, cex = 1.5)
  points(squirrels[((median_p[, visit] - data_visit) > 0.5)[!is.na(data_visit)], c('coordx', 'coordy')],
         col = "blue", pch = 15, cex = 1.5)
  plot(water_raster > 0, add = T, col = "lightblue", legend = F)
}
## dev.off ----
dev.off()
## ----
## training error ----
mean((c(as.matrix(squirrels[, grep('det', colnames(squirrels))])) - t(SPLsamples2[, grep('\\<p', colnames(SPLsamples2))]))^2, na.rm = T)
naive_guess <- mean(as.matrix(Ldata$y), na.rm = T)
mean((c(as.matrix(squirrels[, grep('det', colnames(squirrels))])) - t(SPQsamples2[, grep('\\<p', colnames(SPQsamples2))]))^2, na.rm = T)
naive_guess <- mean(as.matrix(Qdata$y), na.rm = T)
mean((c(as.matrix(squirrels[, grep('det', colnames(squirrels))])) - naive_guess)^2, na.rm = T)
## ESS ----
SPLess_effects <- coda::effectiveSize(coda::mcmc(SPLsamples[, grep('alpha|beta', colnames(SPLsamples))]))
SPLess_effects
SPLess_eta <- coda::effectiveSize(coda::mcmc(SPLsamples2[, grep('eta', colnames(SPLsamples2))]))
quantile(SPLess_eta)
##
SPQess_effects <- coda::effectiveSize(coda::mcmc(SPQsamples[, grep('alpha|beta', colnames(SPQsamples))]))
SPQess_effects
SPQess_eta <- coda::effectiveSize(coda::mcmc(SPQsamples2[, grep('eta', colnames(SPQsamples2))]))
quantile(SPQess_eta)
