################# ----
## libraries ----
library(nimble); library(Matrix); library(raster)
## squirrel data ----
squirrels <- read.table(file = "../data/squirrels/SwissSquirrels.txt", header = T)
N <- nrow(squirrels)
J <- 3
## nimble model code[N, P, KR, SP] ----
source("squirrels/nimble_models.R")
## data lists [N, L, Q] ----
source("squirrels/nimble_data_lists.R")
## create model object [N] ----
Nmodel <- nimbleModel(code = Ncode, constants = Nconstants,
                      data = Ndata, inits = Ninits, check = F)
NmcmcConf <- configureMCMC(Nmodel)
NmcmcConf$addMonitors('p')
Nmcmc <- buildMCMC(NmcmcConf)
CNmodel <- compileNimble(Nmodel)
CNmcmc <- compileNimble(Nmcmc, project = Nmodel)
N_iterations <- 5e4
system.time({
  CNmcmc$run(N_iterations, nburnin = N_iterations / 2)
})
Nsamples <- as.matrix(CNmcmc$mvSamples)
## load chains [P, KR, SP] ----
load(file = "../data/squirrels/poisson_fit.RData")
load(file = "../data/squirrels/KR_fit.RData")
load(file = "../data/squirrels/SP_fit.RData")
## ----
## calc effects [N] ----
## beta
pr_elevation_N <- pr_forest_N <- quantile(Nsamples[, 'psi'], probs = c(0.025, 0.5, 0.975))
## alpha
pr_date_N <- pr_duration_N <- quantile(Nsamples[, 'r'], probs = c(0.025, 0.5, 0.975))
## calc effects [PL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- exp(X_elevation %*% t(PLsamples_transformed[, grep('beta', colnames(PLsamples_transformed))]))
pr_elevation_PL <- t(apply(1 - exp(-lambda_elevation_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- exp(X_forest %*% t(PLsamples_transformed[, grep('beta', colnames(PLsamples_transformed))]))
pr_forest_PL <- t(apply(1 - exp(-lambda_forest_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
probit_pr_date_iter <- X_date %*% t(PLsamples_transformed[, grep('alpha', colnames(PLsamples_transformed))])
pr_date_PL <- t(apply(pnorm(as.matrix(probit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
probit_pr_duration_iter <- X_duration %*% t(PLsamples_transformed[, grep('alpha', colnames(PLsamples_transformed))])
pr_duration_PL <- t(apply(pnorm(as.matrix(probit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## calc grad effects [PL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- exp(X_elevation %*% t(PLsamples_transformed[, grep('beta', colnames(PLsamples_transformed))]))
grad_pr_elevation_PL <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    PLsamples_transformed[, grep('beta\\[2\\]', colnames(PLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- exp(X_forest %*% t(PLsamples_transformed[, grep('beta', colnames(PLsamples_transformed))]))
grad_pr_forest_PL <- t(apply(
  t(exp(-lambda_forest_iter) * lambda_forest_iter) *
    PLsamples_transformed[, grep('beta\\[3\\]', colnames(PLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
probit_pr_date_iter <- X_date %*% t(PLsamples_transformed[, grep('alpha', colnames(PLsamples_transformed))])
grad_pr_date_PL <- t(apply(
  t(dnorm(as.matrix(probit_pr_date_iter))) *
    PLsamples_transformed[, grep('alpha\\[2\\]', colnames(PLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
probit_pr_duration_iter <- X_duration %*% t(PLsamples_transformed[, grep('alpha', colnames(PLsamples_transformed))])
grad_pr_duration_PL <- t(apply(
  t(dnorm(as.matrix(probit_pr_duration_iter))) *
    PLsamples_transformed[, grep('alpha\\[3\\]', colnames(PLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## calc effects [PQ] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- exp(X_elevation %*% t(PQsamples_transformed[, grep('beta', colnames(PQsamples_transformed))]))
pr_elevation_PQ <- t(apply(1 - exp(-lambda_elevation_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- exp(X_forest %*% t(PQsamples_transformed[, grep('beta', colnames(PQsamples_transformed))]))
pr_forest_PQ <- t(apply(1 - exp(-lambda_forest_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
probit_pr_date_iter <- X_date %*% t(PQsamples_transformed[, grep('alpha', colnames(PQsamples_transformed))])
pr_date_PQ <- t(apply(pnorm(as.matrix(probit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
probit_pr_duration_iter <- X_duration %*% t(PQsamples_transformed[, grep('alpha', colnames(PQsamples_transformed))])
pr_duration_PQ <- t(apply(pnorm(as.matrix(probit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## calc grad effects [PQ] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- exp(X_elevation %*% t(PQsamples_transformed[, grep('beta', colnames(PQsamples_transformed))]))
grad_pr_elevation_PQ <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    (PQsamples_transformed[, grep('beta\\[2\\]', colnames(PQsamples_transformed))] +
       2 * t(elev_values %o% PQsamples_transformed[, grep('beta\\[4\\]', colnames(PQsamples_transformed))]) +
       forest_value * PQsamples_transformed[, grep('beta\\[6\\]', colnames(PQsamples_transformed))] +
       2 * forest_value * t(elev_values %o% PQsamples_transformed[, grep('beta\\[7\\]', colnames(PQsamples_transformed))]) +
       forest_value^2 * PQsamples_transformed[, grep('beta\\[8\\]', colnames(PQsamples_transformed))]),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- exp(X_forest %*% t(PQsamples_transformed[, grep('beta', colnames(PQsamples_transformed))]))
grad_pr_forest_PQ <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    (PQsamples_transformed[, grep('beta\\[3\\]', colnames(PQsamples_transformed))] +
       2 * t(forest_values %o% PQsamples_transformed[, grep('beta\\[5\\]', colnames(PQsamples_transformed))]) +
       elev_value * PQsamples_transformed[, grep('beta\\[6\\]', colnames(PQsamples_transformed))] +
       elev_value^2 * PQsamples_transformed[, grep('beta\\[7\\]', colnames(PQsamples_transformed))] +
       2 * elev_value * t(forest_values %o% PQsamples_transformed[, grep('beta\\[8\\]', colnames(PQsamples_transformed))])),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
probit_pr_date_iter <- X_date %*% t(PQsamples_transformed[, grep('alpha', colnames(PQsamples_transformed))])
grad_pr_date_PQ <- t(apply(
  t(dnorm(as.matrix(probit_pr_date_iter))) *
    PQsamples_transformed[, grep('alpha\\[2\\]', colnames(PQsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
probit_pr_duration_iter <- X_duration %*% t(PQsamples_transformed[, grep('alpha', colnames(PQsamples_transformed))])
grad_pr_duration_PQ <- t(apply(
  t(dnorm(as.matrix(probit_pr_duration_iter))) *
    (PQsamples_transformed[, grep('alpha\\[3\\]', colnames(PQsamples_transformed))] +
       2 * t(dur_values %o% PQsamples_transformed[, grep('alpha\\[4\\]', colnames(PQsamples_transformed))])),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## calc effects [KRL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- X_elevation %*% t(KRLsamples_transformed[, grep('beta', colnames(KRLsamples_transformed))])
pr_elevation_KRL <- t(apply(1 / (1 + exp(-lambda_elevation_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- X_forest %*% t(KRLsamples_transformed[, grep('beta', colnames(KRLsamples_transformed))])
pr_forest_KRL <- t(apply(1 / (1 + exp(-lambda_forest_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
logit_pr_date_iter <- X_date %*% t(KRLsamples_transformed[, grep('alpha', colnames(KRLsamples_transformed))])
pr_date_KRL <- t(apply(1 / (1 + exp(-logit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
logit_pr_duration_iter <- X_duration %*% t(KRLsamples_transformed[, grep('alpha', colnames(KRLsamples_transformed))])
pr_duration_KRL <- t(apply(1 / (1 + exp(-logit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## calc grad effects [KRL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- X_elevation %*% t(KRLsamples_transformed[, grep('beta', colnames(KRLsamples_transformed))])
pr_elevation_iter <- 1 / (1 + exp(-lambda_elevation_iter))
grad_pr_elevation_KRL <- t(apply(apply(pr_elevation_iter, 2, diff),
                             1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(elev_values)
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- exp(X_forest %*% t(KRLsamples_transformed[, grep('beta', colnames(KRLsamples_transformed))]))
pr_forest_iter <- 1 / (1 + exp(-lambda_forest_iter))
grad_pr_forest_KRL <- t(apply(apply(pr_forest_iter, 2, diff),
                          1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(forest_values)
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
logit_pr_date_iter <- X_date %*% t(KRLsamples_transformed[, grep('alpha', colnames(KRLsamples_transformed))])
pr_date_iter <- 1 / (1 + exp(-logit_pr_date_iter))
grad_pr_date_KRL <- t(apply(apply(pr_date_iter, 2, diff),
                        1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(date_values)
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
logit_pr_duration_iter <- X_duration %*% t(KRLsamples_transformed[, grep('alpha', colnames(KRLsamples_transformed))])
pr_duration_iter <- 1 / (1 + exp(-logit_pr_duration_iter))
grad_pr_duration_KRL <- t(apply(apply(pr_duration_iter, 2, diff),
                            1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(dur_values)
## calc effects [KRQ] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- X_elevation %*% t(KRQsamples_transformed[, grep('beta', colnames(KRQsamples_transformed))])
pr_elevation_KRQ <- t(apply(1 / (1 + exp(-lambda_elevation_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- X_forest %*% t(KRQsamples_transformed[, grep('beta', colnames(KRQsamples_transformed))])
pr_forest_KRQ <- t(apply(1 / (1 + exp(-lambda_forest_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
logit_pr_date_iter <- X_date %*% t(KRQsamples_transformed[, grep('alpha', colnames(KRQsamples_transformed))])
pr_date_KRQ <- t(apply(1 / (1 + exp(-logit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
logit_pr_duration_iter <- X_duration %*% t(KRQsamples_transformed[, grep('alpha', colnames(KRQsamples_transformed))])
pr_duration_KRQ <- t(apply(1 / (1 + exp(-logit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## calc grad effects [KRQ] ----
## beta
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- X_elevation %*% t(KRQsamples_transformed[, grep('beta', colnames(KRQsamples_transformed))])
pr_elevation_iter <- 1 / (1 + exp(-lambda_elevation_iter))
grad_pr_elevation_KRQ <- t(apply(apply(pr_elevation_iter, 2, diff),
                             1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(elev_values)
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- X_forest %*% t(KRQsamples_transformed[, grep('beta', colnames(KRQsamples_transformed))])
pr_forest_iter <- 1 / (1 + exp(-lambda_forest_iter))
grad_pr_forest_KRQ <- t(apply(apply(pr_forest_iter, 2, diff),
                          1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(forest_values)
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
logit_pr_date_iter <- X_date %*% t(KRQsamples_transformed[, grep('alpha', colnames(KRQsamples_transformed))])
pr_date_iter <- 1 / (1 + exp(-logit_pr_date_iter))
grad_pr_date_KRQ <- t(apply(apply(pr_date_iter, 2, diff),
                        1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(date_values)
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
logit_pr_duration_iter <- X_duration %*% t(KRQsamples_transformed[, grep('alpha', colnames(KRQsamples_transformed))])
pr_duration_iter <- 1 / (1 + exp(-logit_pr_duration_iter))
grad_pr_duration_KRQ <- t(apply(apply(pr_duration_iter, 2, diff),
                            1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(dur_values)
## calc effects [SPL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- exp(X_elevation %*% t(SPLsamples_transformed[, grep('beta', colnames(SPLsamples_transformed))]))
pr_elevation_SPL <- t(apply(1 - exp(-lambda_elevation_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- exp(X_forest %*% t(SPLsamples_transformed[, grep('beta', colnames(SPLsamples_transformed))]))
pr_forest_SPL <- t(apply(1 - exp(-lambda_forest_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
probit_pr_date_iter <- X_date %*% t(SPLsamples_transformed[, grep('alpha', colnames(SPLsamples_transformed))])
pr_date_SPL <- t(apply(pnorm(as.matrix(probit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
probit_pr_duration_iter <- X_duration %*% t(SPLsamples_transformed[, grep('alpha', colnames(SPLsamples_transformed))])
pr_duration_SPL <- t(apply(pnorm(as.matrix(probit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## calc grad effects [SPL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- exp(X_elevation %*% t(SPLsamples_transformed[, grep('beta', colnames(SPLsamples_transformed))]))
grad_pr_elevation_SPL <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    SPLsamples_transformed[, grep('beta\\[2\\]', colnames(SPLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- exp(X_forest %*% t(SPLsamples_transformed[, grep('beta', colnames(SPLsamples_transformed))]))
pr_forest_iter <- 1 - exp(-lambda_forest_iter)
grad_pr_forest_SPL <- t(apply(
  t(exp(-lambda_forest_iter) * lambda_forest_iter) *
    SPLsamples_transformed[, grep('beta\\[3\\]', colnames(SPLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
probit_pr_date_iter <- X_date %*% t(SPLsamples_transformed[, grep('alpha', colnames(SPLsamples_transformed))])
grad_pr_date_SPL <- t(apply(
  t(dnorm(as.matrix(probit_pr_date_iter))) *
    SPLsamples_transformed[, grep('alpha\\[2\\]', colnames(SPLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
probit_pr_duration_iter <- X_duration %*% t(SPLsamples_transformed[, grep('alpha', colnames(SPLsamples_transformed))])
grad_pr_duration_SPL <- t(apply(
  t(dnorm(as.matrix(probit_pr_duration_iter))) *
    SPLsamples_transformed[, grep('alpha\\[3\\]', colnames(SPLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## calc effects [SPQ] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- exp(X_elevation %*% t(SPQsamples_transformed[, grep('beta', colnames(SPQsamples_transformed))]))
pr_elevation_SPQ <- t(apply(1 - exp(-lambda_elevation_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- exp(X_forest %*% t(SPQsamples_transformed[, grep('beta', colnames(SPQsamples_transformed))]))
pr_forest_SPQ <- t(apply(1 - exp(-lambda_forest_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
probit_pr_date_iter <- X_date %*% t(SPQsamples_transformed[, grep('alpha', colnames(SPQsamples_transformed))])
pr_date_SPQ <- t(apply(pnorm(as.matrix(probit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
probit_pr_duration_iter <- X_duration %*% t(SPQsamples_transformed[, grep('alpha', colnames(SPQsamples_transformed))])
pr_duration_SPQ <- t(apply(pnorm(as.matrix(probit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## calc grad effects [SPQ] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- exp(X_elevation %*% t(SPQsamples_transformed[, grep('beta', colnames(SPQsamples_transformed))]))
grad_pr_elevation_SPQ <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    (SPQsamples_transformed[, grep('beta\\[2\\]', colnames(SPQsamples_transformed))] +
       2 * t(elev_values %o% SPQsamples_transformed[, grep('beta\\[4\\]', colnames(SPQsamples_transformed))]) +
       forest_value * SPQsamples_transformed[, grep('beta\\[6\\]', colnames(SPQsamples_transformed))] +
       2 * forest_value * t(elev_values %o% SPQsamples_transformed[, grep('beta\\[7\\]', colnames(SPQsamples_transformed))]) +
       forest_value^2 * SPQsamples_transformed[, grep('beta\\[8\\]', colnames(SPQsamples_transformed))]),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- exp(X_forest %*% t(SPQsamples_transformed[, grep('beta', colnames(SPQsamples_transformed))]))
pr_forest_iter <- 1 - exp(-lambda_forest_iter)
grad_pr_forest_SPQ <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    (SPQsamples_transformed[, grep('beta\\[3\\]', colnames(SPQsamples_transformed))] +
       2 * t(forest_values %o% SPQsamples_transformed[, grep('beta\\[5\\]', colnames(SPQsamples_transformed))]) +
       elev_value * SPQsamples_transformed[, grep('beta\\[6\\]', colnames(SPQsamples_transformed))] +
       elev_value^2 * SPQsamples_transformed[, grep('beta\\[7\\]', colnames(SPQsamples_transformed))] +
       2 * elev_value * t(forest_values %o% SPQsamples_transformed[, grep('beta\\[8\\]', colnames(SPQsamples_transformed))])),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
probit_pr_date_iter <- X_date %*% t(SPQsamples_transformed[, grep('alpha', colnames(SPQsamples_transformed))])
grad_pr_date_SPQ <- t(apply(
  t(dnorm(as.matrix(probit_pr_date_iter))) *
    SPQsamples_transformed[, grep('alpha\\[2\\]', colnames(SPQsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
probit_pr_duration_iter <- X_duration %*% t(SPQsamples_transformed[, grep('alpha', colnames(SPQsamples_transformed))])
grad_pr_duration_SPQ <- t(apply(
  t(dnorm(as.matrix(probit_pr_duration_iter))) *
    (SPQsamples_transformed[, grep('alpha\\[3\\]', colnames(SPQsamples_transformed))] +
       2 * t(dur_values %o% SPQsamples_transformed[, grep('alpha\\[4\\]', colnames(SPQsamples_transformed))])),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## device ----
pdf(file = "../fig/squirrels_effects_all.pdf", width = 8.5 * 0.85, height = 7.4 * 0.85)
## layout ----
model_colors <- RColorBrewer::brewer.pal(12, "Paired")[c(1:2, 7:8, 9:10, 12)]
model_colors <- RColorBrewer::brewer.pal(7, "Dark2")[c(1, 5, 2, 4, 6, 7, 3)]
pchs <- c(1, 5, 3, 4, 2, 6, 7)
layout(matrix(1:4, 2, 2, byrow = T)); par(mar = c(4.1, 4.1, 2.1, 2.1), oma = c(0, 0, 1, 0))
label_offset_x <- 0.03; label_offset_y <- 0.05
lwds <- c(1, 3, 1); ltys <- c(3, 1, 3); poly_alpha <- 0.1
## plot effects [elev] ----
matplot(elev_values, pr_elevation_PL, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, ylim = 0:1, las = 1,
        ylab = expression("Pred. occupancy prob."*(psi)), xlab = "Elevation (m)", bty = "n")
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_PL[, 1], rev(pr_elevation_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_PQ[, 1], rev(pr_elevation_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_KRL[, 1], rev(pr_elevation_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_KRQ[, 1], rev(pr_elevation_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_SPL[, 1], rev(pr_elevation_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_SPQ[, 1], rev(pr_elevation_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
polygon(x = elev_values[c(1, length(elev_values), length(elev_values), 1)],
        y = c(pr_elevation_N[1], pr_elevation_N[1], pr_elevation_N[3], pr_elevation_N[3]),
        border = NA, col = scales::alpha(model_colors[7], poly_alpha))
matplot(elev_values[c(1, length(elev_values))], t(matrix(pr_elevation_N, 3, 2)),
        type = "l", add = T, lty = ltys, col = model_colors[7], lwd = lwds)
matplot(elev_values, pr_elevation_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(elev_values, pr_elevation_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(elev_values, pr_elevation_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(elev_values, pr_elevation_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(elev_values, pr_elevation_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(elev_values, pr_elevation_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
points(jitter(elev), apply(Ldata$y, 1, max, na.rm = T))
# legend("bottomleft", legend = c("PL", "KRL", "SPL", "PQ", "KRQ", "SPQ"),
#        lty = 1, lwd = 3, col = model_colors[c(1, 3, 5, 2, 4, 6)], ncol = 2, bty = "n")
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(a)", xpd = T, cex = 1.5)
## plot effects [forest]  ----
matplot(forest_values, pr_forest_PL, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, ylim = 0:1, las = 1,
        ylab = expression("Pred. occupancy prob."*(psi)), xlab = "Forest cover (%)", bty = "n")
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_PL[, 1], rev(pr_forest_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_PQ[, 1], rev(pr_forest_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_KRL[, 1], rev(pr_forest_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_KRQ[, 1], rev(pr_forest_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_SPL[, 1], rev(pr_forest_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_SPQ[, 1], rev(pr_forest_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
polygon(x = forest_values[c(1, length(forest_values), length(forest_values), 1)],
        y = c(pr_forest_N[1], pr_forest_N[1], pr_forest_N[3], pr_forest_N[3]),
        border = NA, col = scales::alpha(model_colors[7], poly_alpha))
matplot(forest_values[c(1, length(forest_values))], t(matrix(pr_forest_N, 3, 2)),
        type = "l", add = T, lty = ltys, col = model_colors[7], lwd = lwds)
matplot(forest_values, pr_forest_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(forest_values, pr_forest_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(forest_values, pr_forest_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(forest_values, pr_forest_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(forest_values, pr_forest_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(forest_values, pr_forest_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
legend("bottomright", legend = c(NA, NA, "Naive", "PL", "KRL", "SPL", "PQ", "KRQ", "SPQ"),
       lty = 1, lwd = 3, col = c(NA, NA, model_colors[c(7, 1, 3, 5, 2, 4, 6)]), ncol = 3, bty = "n")
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(b)", xpd = T, cex = 1.5)
## plot effects [date]  ----
matplot(date_values, pr_date_PL, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, ylim = 0:1, las = 1,
        ylab = expression("Pred. detection prob."*(r)), xlab = "Date (1 = 1 April)", bty = "n")
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_PL[, 1], rev(pr_date_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_PQ[, 1], rev(pr_date_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_KRL[, 1], rev(pr_date_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_KRQ[, 1], rev(pr_date_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_SPL[, 1], rev(pr_date_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_SPQ[, 1], rev(pr_date_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
polygon(x = date_values[c(1, length(date_values), length(date_values), 1)],
        y = c(pr_date_N[1], pr_date_N[1], pr_date_N[3], pr_date_N[3]),
        border = NA, col = scales::alpha(model_colors[7], poly_alpha))
matplot(date_values[c(1, length(date_values))], t(matrix(pr_date_N, 3, 2)),
        type = "l", add = T, lty = ltys, col = model_colors[7], lwd = lwds)
matplot(date_values, pr_date_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(date_values, pr_date_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(date_values, pr_date_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(date_values, pr_date_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(date_values, pr_date_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(date_values, pr_date_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(c)", xpd = T, cex = 1.5)
## plot effects [duration]  ----
matplot(dur_values, pr_duration_PL, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, ylim = 0:1, las = 1,
        ylab = expression("Pred. detection prob."*(r)), xlab = "Survey duration (min)", bty = "n")
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_PL[, 1], rev(pr_duration_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_PQ[, 1], rev(pr_duration_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_KRL[, 1], rev(pr_duration_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_KRQ[, 1], rev(pr_duration_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_SPL[, 1], rev(pr_duration_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_SPQ[, 1], rev(pr_duration_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
polygon(x = dur_values[c(1, length(dur_values), length(dur_values), 1)],
        y = c(pr_duration_N[1], pr_duration_N[1], pr_duration_N[3], pr_duration_N[3]),
        border = NA, col = scales::alpha(model_colors[7], poly_alpha))
matplot(dur_values[c(1, length(dur_values))], t(matrix(pr_duration_N, 3, 2)),
        type = "l", add = T, lty = ltys, col = model_colors[7], lwd = lwds)
matplot(dur_values, pr_duration_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(dur_values, pr_duration_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(dur_values, pr_duration_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(dur_values, pr_duration_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(dur_values, pr_duration_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(dur_values, pr_duration_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
title(main = "Probability curves", outer = T, line = 0, cex.main = 1.5)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(d)", xpd = T, cex = 1.5)
## dev.off ----
dev.off()
## device ----
pdf(file = "../fig/squirrels_grad_effects_all.pdf", width = 8.5 * 0.85, height = 7.4 * 0.85)
## layout ----
layout(matrix(1:4, 2, 2, byrow = T)); par(mar = c(4.1, 4.1, 2.1, 2.1), oma = c(0, 0, 1, 0))
## plot grad effects [elev] ----
matplot(elev_values, 1e2 * grad_pr_elevation_SPQ, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, las = 1,
        ylab = expression(Delta*psi/100*m), xlab = "Elevation (m)", bty = "n")
polygon(x = c(elev_values, rev(elev_values)),
        y = 1e2 * c(grad_pr_elevation_PL[, 1], rev(grad_pr_elevation_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = 1e2 * c(grad_pr_elevation_PQ[, 1], rev(grad_pr_elevation_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(elev_values[-1], rev(elev_values[-1])),
        y = 1e2 * c(grad_pr_elevation_KRL[, 1], rev(grad_pr_elevation_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(elev_values[-1], rev(elev_values[-1])),
        y = 1e2 * c(grad_pr_elevation_KRQ[, 1], rev(grad_pr_elevation_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = 1e2 * c(grad_pr_elevation_SPL[, 1], rev(grad_pr_elevation_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = 1e2 * c(grad_pr_elevation_SPQ[, 1], rev(grad_pr_elevation_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
lines(range(elev_values), c(0, 0), col = model_colors[7], lwd = 3)
matplot(elev_values[c(1, length(elev_values))], t(matrix(pr_elevation_N, 3, 2)),
        type = "l", add = T, lty = ltys, col = model_colors[7], lwd = lwds)
matplot(elev_values, 1e2 * grad_pr_elevation_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(elev_values, 1e2 * grad_pr_elevation_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(elev_values[-1], 1e2 * grad_pr_elevation_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(elev_values[-1], 1e2 * grad_pr_elevation_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(elev_values, 1e2 * grad_pr_elevation_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(elev_values, 1e2 * grad_pr_elevation_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
legend("topright", legend = c(NA, NA, "Naive", "PL", "KRL", "SPL", "PQ", "KRQ", "SPQ"),
       lty = 1, lwd = 3, col = c(NA, NA, model_colors[c(7, 1, 3, 5, 2, 4, 6)]), ncol = 3, bty = "n")
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(a)", xpd = T, cex = 1.5)
## plot grad effects [forest] ----
matplot(forest_values, 10 * grad_pr_forest_SPQ, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, las = 1, ylim = c(-0.1, 0.35),
        ylab = expression(Delta*psi/10*"%"), xlab = "Forest cover (%)", bty = "n")
polygon(x = c(forest_values, rev(forest_values)),
        y = 10 * c(grad_pr_forest_PL[, 1], rev(grad_pr_forest_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = 10 * c(grad_pr_forest_PQ[, 1], rev(grad_pr_forest_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(forest_values[-1], rev(forest_values[-1])),
        y = 10 * c(grad_pr_forest_KRL[, 1], rev(grad_pr_forest_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(forest_values[-1], rev(forest_values[-1])),
        y = 10 * c(grad_pr_forest_KRQ[, 1], rev(grad_pr_forest_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = 10 * c(grad_pr_forest_SPL[, 1], rev(grad_pr_forest_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = 10 * c(grad_pr_forest_SPQ[, 1], rev(grad_pr_forest_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
lines(range(forest_values), c(0, 0), col = model_colors[7], lwd = 3)
matplot(forest_values, 10 * grad_pr_forest_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(forest_values, 10 * grad_pr_forest_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(forest_values[-1], 10 * grad_pr_forest_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(forest_values[-1], 10 * grad_pr_forest_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(forest_values, 10 * grad_pr_forest_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(forest_values, 10 * grad_pr_forest_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(b)", xpd = T, cex = 1.5)
## plot grad effects [date] ----
matplot(date_values, 30 * grad_pr_date_SPQ, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, las = 1, ylim = c(-0.2, 0.05),
        ylab = expression(Delta*r/month), xlab = "Date (1 = 1 April)", bty = "n")
polygon(x = c(date_values, rev(date_values)),
        y = 30 * c(grad_pr_date_PL[, 1], rev(grad_pr_date_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = 30 * c(grad_pr_date_PQ[, 1], rev(grad_pr_date_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(date_values[-1], rev(date_values[-1])),
        y = 30 * c(grad_pr_date_KRL[, 1], rev(grad_pr_date_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(date_values[-1], rev(date_values[-1])),
        y = 30 * c(grad_pr_date_KRQ[, 1], rev(grad_pr_date_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = 30 * c(grad_pr_date_SPL[, 1], rev(grad_pr_date_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = 30 * c(grad_pr_date_SPQ[, 1], rev(grad_pr_date_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
lines(range(date_values), c(0, 0), col = model_colors[7], lwd = 3)
matplot(date_values, 30 * grad_pr_date_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(date_values, 30 * grad_pr_date_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(date_values[-1], 30 * grad_pr_date_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(date_values[-1], 30 * grad_pr_date_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(date_values, 30 * grad_pr_date_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(date_values, 30 * grad_pr_date_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(c)", xpd = T, cex = 1.5)
## plot grad effects [duration] ----
matplot(dur_values, 60 * grad_pr_duration_SPQ, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, las = 1,
        ylab = expression(Delta*r/hr), xlab = "Survey duration (min)", bty = "n")
polygon(x = c(dur_values, rev(dur_values)),
        y = 60 * c(grad_pr_duration_PL[, 1], rev(grad_pr_duration_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = 60 * c(grad_pr_duration_PQ[, 1], rev(grad_pr_duration_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(dur_values[-1], rev(dur_values[-1])),
        y = 60 * c(grad_pr_duration_KRL[, 1], rev(grad_pr_duration_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(dur_values[-1], rev(dur_values[-1])),
        y = 60 * c(grad_pr_duration_KRQ[, 1], rev(grad_pr_duration_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = 60 * c(grad_pr_duration_SPL[, 1], rev(grad_pr_duration_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = 60 * c(grad_pr_duration_SPQ[, 1], rev(grad_pr_duration_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
lines(range(dur_values), c(0, 0), col = model_colors[7], lwd = 3)
matplot(dur_values, 60 * grad_pr_duration_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(dur_values, 60 * grad_pr_duration_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(dur_values[-1], 60 * grad_pr_duration_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(dur_values[-1], 60 * grad_pr_duration_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(dur_values, 60 * grad_pr_duration_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(dur_values, 60 * grad_pr_duration_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
title(main = "Probability curve gradients", outer = T, line = 0, cex.main = 1.5)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(d)", xpd = T, cex = 1.5)
## dev.off ----
dev.off()


# ## ALL TOGETHER ----
## device ----
pdf(file = "../fig/squirrels_all.pdf", width = 8.5, height = 4.5)
## layout ----
model_colors <- RColorBrewer::brewer.pal(12, "Paired")[c(1:2, 7:8, 9:10, 12)]
model_colors <- RColorBrewer::brewer.pal(7, "Dark2")[c(1, 5, 2, 4, 6, 7, 3)]
pchs <- c(1, 5, 3, 4, 2, 6, 7)
layout(matrix(1:8, 2, 4, byrow = T), heights = c(0.9, 1, 0.9, 1))
par(oma = c(0, 0, 1, 0))
label_offset_x <- 0.03; label_offset_y <- 0.05
lwds <- c(1, 3, 1); ltys <- c(3, 1, 3); poly_alpha <- 0.1
## plot effects [elev]  ----
par(mar = c(1.1, 4.1, 1.6, 0.1))
matplot(elev_values, pr_elevation_PL, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, ylim = 0:1, las = 1,
        ylab = expression("Pred. occupancy prob."*(psi)),
        xlab = "", xaxt = "n", bty = "n")
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_PL[, 1], rev(pr_elevation_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_PQ[, 1], rev(pr_elevation_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_KRL[, 1], rev(pr_elevation_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_KRQ[, 1], rev(pr_elevation_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_SPL[, 1], rev(pr_elevation_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = c(pr_elevation_SPQ[, 1], rev(pr_elevation_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
polygon(x = elev_values[c(1, length(elev_values), length(elev_values), 1)],
        y = c(pr_elevation_N[1], pr_elevation_N[1], pr_elevation_N[3], pr_elevation_N[3]),
        border = NA, col = scales::alpha(model_colors[7], poly_alpha))
matplot(elev_values[c(1, length(elev_values))], t(matrix(pr_elevation_N, 3, 2)),
        type = "l", add = T, lty = ltys, col = model_colors[7], lwd = lwds)
matplot(elev_values, pr_elevation_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(elev_values, pr_elevation_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(elev_values, pr_elevation_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(elev_values, pr_elevation_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(elev_values, pr_elevation_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(elev_values, pr_elevation_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(a)", xpd = T, cex = 1.5)
## plot effects [forest]  ----
par(mar = c(1.1, 4.1, 1.6, 0.1))
matplot(forest_values, pr_forest_PL, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, ylim = 0:1, las = 1,
        ylab = "", yaxt = "n",
        xlab = "", xaxt = "n", bty = "n")
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_PL[, 1], rev(pr_forest_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_PQ[, 1], rev(pr_forest_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_KRL[, 1], rev(pr_forest_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_KRQ[, 1], rev(pr_forest_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_SPL[, 1], rev(pr_forest_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = c(pr_forest_SPQ[, 1], rev(pr_forest_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
polygon(x = forest_values[c(1, length(forest_values), length(forest_values), 1)],
        y = c(pr_forest_N[1], pr_forest_N[1], pr_forest_N[3], pr_forest_N[3]),
        border = NA, col = scales::alpha(model_colors[7], poly_alpha))
matplot(forest_values[c(1, length(forest_values))], t(matrix(pr_forest_N, 3, 2)),
        type = "l", add = T, lty = ltys, col = model_colors[7], lwd = lwds)
matplot(forest_values, pr_forest_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(forest_values, pr_forest_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(forest_values, pr_forest_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(forest_values, pr_forest_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(forest_values, pr_forest_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(forest_values, pr_forest_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(b)", xpd = T, cex = 1.5)
## plot effects [date]  ----
par(mar = c(1.1, 4.1, 1.6, 0.1))
matplot(date_values, pr_date_PL, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, ylim = 0:1, las = 1,
        ylab = expression("Pred. detection prob."*(r)),
        xlab = "", xaxt = "n", bty = "n")
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_PL[, 1], rev(pr_date_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_PQ[, 1], rev(pr_date_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_KRL[, 1], rev(pr_date_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_KRQ[, 1], rev(pr_date_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_SPL[, 1], rev(pr_date_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = c(pr_date_SPQ[, 1], rev(pr_date_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
polygon(x = date_values[c(1, length(date_values), length(date_values), 1)],
        y = c(pr_date_N[1], pr_date_N[1], pr_date_N[3], pr_date_N[3]),
        border = NA, col = scales::alpha(model_colors[7], poly_alpha))
matplot(date_values[c(1, length(date_values))], t(matrix(pr_date_N, 3, 2)),
        type = "l", add = T, lty = ltys, col = model_colors[7], lwd = lwds)
matplot(date_values, pr_date_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(date_values, pr_date_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(date_values, pr_date_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(date_values, pr_date_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(date_values, pr_date_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(date_values, pr_date_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(c)", xpd = T, cex = 1.5)
## plot effects [duration]  ----
par(mar = c(1.1, 4.1, 1.6, 0.1))
matplot(dur_values, pr_duration_PL, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, ylim = 0:1, las = 1,
        ylab = "", xlab = "", axes = F, bty = "n")
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_PL[, 1], rev(pr_duration_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_PQ[, 1], rev(pr_duration_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_KRL[, 1], rev(pr_duration_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_KRQ[, 1], rev(pr_duration_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_SPL[, 1], rev(pr_duration_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = c(pr_duration_SPQ[, 1], rev(pr_duration_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
polygon(x = dur_values[c(1, length(dur_values), length(dur_values), 1)],
        y = c(pr_duration_N[1], pr_duration_N[1], pr_duration_N[3], pr_duration_N[3]),
        border = NA, col = scales::alpha(model_colors[7], poly_alpha))
matplot(dur_values[c(1, length(dur_values))], t(matrix(pr_duration_N, 3, 2)),
        type = "l", add = T, lty = ltys, col = model_colors[7], lwd = lwds)
matplot(dur_values, pr_duration_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(dur_values, pr_duration_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(dur_values, pr_duration_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(dur_values, pr_duration_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(dur_values, pr_duration_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(dur_values, pr_duration_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(d)", xpd = T, cex = 1.5)
## plot grad effects [elev] ----
par(mar = c(4.1, 4.1, 1.6, 0.1))
matplot(elev_values, 1e2 * grad_pr_elevation_SPQ, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, las = 1,
        ylab = expression(Delta*psi/100*m), xlab = "Elevation (m)", bty = "n")
polygon(x = c(elev_values, rev(elev_values)),
        y = 1e2 * c(grad_pr_elevation_PL[, 1], rev(grad_pr_elevation_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = 1e2 * c(grad_pr_elevation_PQ[, 1], rev(grad_pr_elevation_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(elev_values[-1], rev(elev_values[-1])),
        y = 1e2 * c(grad_pr_elevation_KRL[, 1], rev(grad_pr_elevation_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(elev_values[-1], rev(elev_values[-1])),
        y = 1e2 * c(grad_pr_elevation_KRQ[, 1], rev(grad_pr_elevation_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = 1e2 * c(grad_pr_elevation_SPL[, 1], rev(grad_pr_elevation_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(elev_values, rev(elev_values)),
        y = 1e2 * c(grad_pr_elevation_SPQ[, 1], rev(grad_pr_elevation_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
lines(range(elev_values), c(0, 0), col = model_colors[7], lwd = 3)
matplot(elev_values[c(1, length(elev_values))], t(matrix(pr_elevation_N, 3, 2)),
        type = "l", add = T, lty = ltys, col = model_colors[7], lwd = lwds)
matplot(elev_values, 1e2 * grad_pr_elevation_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(elev_values, 1e2 * grad_pr_elevation_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(elev_values[-1], 1e2 * grad_pr_elevation_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(elev_values[-1], 1e2 * grad_pr_elevation_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(elev_values, 1e2 * grad_pr_elevation_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(elev_values, 1e2 * grad_pr_elevation_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
legend("topright", legend = c("Naive", "PL", "KRL", "SPL", NA, "PQ", "KRQ", "SPQ"),
       lty = 1, lwd = 3, col = model_colors[c(7, 1, 3, 5, NA, 2, 4, 6)],
       ncol = 2, bty = "n")
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(e)", xpd = T, cex = 1.5)
## plot grad effects [forest] ----
par(mar = c(4.1, 4.1, 1.6, 0.1))
matplot(forest_values, 10 * grad_pr_forest_SPQ, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, las = 1, ylim = c(-0.1, 0.35),
        ylab = expression(Delta*psi/10*"%"),
        xlab = "Forest cover (%)", bty = "n")
polygon(x = c(forest_values, rev(forest_values)),
        y = 10 * c(grad_pr_forest_PL[, 1], rev(grad_pr_forest_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = 10 * c(grad_pr_forest_PQ[, 1], rev(grad_pr_forest_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(forest_values[-1], rev(forest_values[-1])),
        y = 10 * c(grad_pr_forest_KRL[, 1], rev(grad_pr_forest_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(forest_values[-1], rev(forest_values[-1])),
        y = 10 * c(grad_pr_forest_KRQ[, 1], rev(grad_pr_forest_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = 10 * c(grad_pr_forest_SPL[, 1], rev(grad_pr_forest_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(forest_values, rev(forest_values)),
        y = 10 * c(grad_pr_forest_SPQ[, 1], rev(grad_pr_forest_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
lines(range(forest_values), c(0, 0), col = model_colors[7], lwd = 3)
matplot(forest_values, 10 * grad_pr_forest_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(forest_values, 10 * grad_pr_forest_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(forest_values[-1], 10 * grad_pr_forest_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(forest_values[-1], 10 * grad_pr_forest_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(forest_values, 10 * grad_pr_forest_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(forest_values, 10 * grad_pr_forest_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(f)", xpd = T, cex = 1.5)
## plot grad effects [date] ----
par(mar = c(4.1, 4.1, 1.6, 0.1))
matplot(date_values, 30 * grad_pr_date_SPQ, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, las = 1, ylim = c(-0.2, 0.05),
        ylab = expression(Delta*r/month), xlab = "Date (1 = 1 April)", bty = "n")
polygon(x = c(date_values, rev(date_values)),
        y = 30 * c(grad_pr_date_PL[, 1], rev(grad_pr_date_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = 30 * c(grad_pr_date_PQ[, 1], rev(grad_pr_date_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(date_values[-1], rev(date_values[-1])),
        y = 30 * c(grad_pr_date_KRL[, 1], rev(grad_pr_date_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(date_values[-1], rev(date_values[-1])),
        y = 30 * c(grad_pr_date_KRQ[, 1], rev(grad_pr_date_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = 30 * c(grad_pr_date_SPL[, 1], rev(grad_pr_date_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(date_values, rev(date_values)),
        y = 30 * c(grad_pr_date_SPQ[, 1], rev(grad_pr_date_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
lines(range(date_values), c(0, 0), col = model_colors[7], lwd = 3)
matplot(date_values, 30 * grad_pr_date_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(date_values, 30 * grad_pr_date_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(date_values[-1], 30 * grad_pr_date_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(date_values[-1], 30 * grad_pr_date_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(date_values, 30 * grad_pr_date_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(date_values, 30 * grad_pr_date_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(g)", xpd = T, cex = 1.5)
## plot grad effects [duration] ----
par(mar = c(4.1, 4.1, 1.6, 0.1))
matplot(dur_values, 60 * grad_pr_duration_SPQ, type = "n", lty = ltys,
        col = model_colors[1], lwd = lwds, las = 1,
        ylab = expression(Delta*r/hr), xlab = "Survey duration (min)", bty = "n")
polygon(x = c(dur_values, rev(dur_values)),
        y = 60 * c(grad_pr_duration_PL[, 1], rev(grad_pr_duration_PL[, 3])),
        border = NA, col = scales::alpha(model_colors[1], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = 60 * c(grad_pr_duration_PQ[, 1], rev(grad_pr_duration_PQ[, 3])),
        border = NA, col = scales::alpha(model_colors[2], poly_alpha))
polygon(x = c(dur_values[-1], rev(dur_values[-1])),
        y = 60 * c(grad_pr_duration_KRL[, 1], rev(grad_pr_duration_KRL[, 3])),
        border = NA, col = scales::alpha(model_colors[3], poly_alpha))
polygon(x = c(dur_values[-1], rev(dur_values[-1])),
        y = 60 * c(grad_pr_duration_KRQ[, 1], rev(grad_pr_duration_KRQ[, 3])),
        border = NA, col = scales::alpha(model_colors[4], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = 60 * c(grad_pr_duration_SPL[, 1], rev(grad_pr_duration_SPL[, 3])),
        border = NA, col = scales::alpha(model_colors[5], poly_alpha))
polygon(x = c(dur_values, rev(dur_values)),
        y = 60 * c(grad_pr_duration_SPQ[, 1], rev(grad_pr_duration_SPQ[, 3])),
        border = NA, col = scales::alpha(model_colors[6], poly_alpha))
lines(range(dur_values), c(0, 0), col = model_colors[7], lwd = 3)
matplot(dur_values, 60 * grad_pr_duration_PL, type = "l", lty = ltys, add = T,
        col = model_colors[1], lwd = lwds)
matplot(dur_values, 60 * grad_pr_duration_PQ, type = "l", lty = ltys, add = T,
        col = model_colors[2], lwd = lwds)
matplot(dur_values[-1], 60 * grad_pr_duration_KRL, type = "l", lty = ltys, add = T,
        col = model_colors[3], lwd = lwds)
matplot(dur_values[-1], 60 * grad_pr_duration_KRQ, type = "l", lty = ltys, add = T,
        col = model_colors[4], lwd = lwds)
matplot(dur_values, 60 * grad_pr_duration_SPL, type = "l", lty = ltys,
        col = model_colors[5], lwd = lwds, add = T)
matplot(dur_values, 60 * grad_pr_duration_SPQ, type = "l", lty = ltys,
        col = model_colors[6], lwd = lwds, add = T)
text(par()$usr[1] - label_offset_x * diff(par()$usr[1:2]),
     par()$usr[4] + label_offset_y * diff(par()$usr[3:4]), "(h)", xpd = T, cex = 1.5)
## dev.off ----
dev.off()

## ----
## compute residual samples ----
set.seed(2021)
N_post <- nrow(Nsamples)
iter_subset <- sample(1:N_post, size = 1e3)
elev_bins <- seq(250, 2750, l = 6)
forest_bins <- seq(0, 100, l = 6)
get_binned_resid <- function(samples, X, bins = 12,
                             observations = squirrels[, grep('det', colnames(squirrels))]){
  if(length(bins) == 1){
    bins <- seq(min(X), max(X), l = bins + 1)
  }
  n_bins <- length(bins) - 1
  bin_centers <- (bins[-1] + bins[-c(n_bins + 1)]) / 2
  bin_resids <- apply(samples, 1, function(iter){
    predictions <- matrix(iter, N, J)
    residuals <- observations - predictions
    sapply(1:n_bins, function(i){
      mean(as.matrix(residuals[X > bins[i] & X <= bins[i + 1], ]), na.rm = T)
    })
  })
  return(list("bin_resids" = bin_resids,
              "bin_centers" = bin_centers))
}
## naive
bin_elev <- get_binned_resid(Nsamples[iter_subset, grep('\\<p\\[', colnames(Nsamples))],
                            elev, elev_bins)
bin_forest <- get_binned_resid(Nsamples[iter_subset, grep('\\<p\\[', colnames(Nsamples))],
                               forest, forest_bins)
## Poisson
PL_bin_elev <- get_binned_resid(PLsamples2[iter_subset, grep('\\<p\\[', colnames(PLsamples2))],
                                elev, elev_bins)
PL_bin_forest <- get_binned_resid(PLsamples2[iter_subset, grep('\\<p\\[', colnames(PLsamples2))],
                                  forest, forest_bins)
PQ_bin_elev <- get_binned_resid(PQsamples2[iter_subset, grep('\\<p\\[', colnames(PQsamples2))],
                                elev, elev_bins)
PQ_bin_forest <- get_binned_resid(PQsamples2[iter_subset, grep('\\<p\\[', colnames(PQsamples2))],
                                  forest, forest_bins)
## Kery-Royle
KRL_bin_elev <- get_binned_resid(KRLsamples2[iter_subset, grep('\\<p\\[', colnames(KRLsamples2))],
                                 elev, elev_bins)
KRL_bin_forest <- get_binned_resid(KRLsamples2[iter_subset, grep('\\<p\\[', colnames(KRLsamples2))],
                                   forest, forest_bins)
##
KRQ_bin_elev <- get_binned_resid(KRQsamples2[iter_subset, grep('\\<p\\[', colnames(KRQsamples2))],
                                 elev, elev_bins)
KRQ_bin_forest <- get_binned_resid(KRQsamples2[iter_subset, grep('\\<p\\[', colnames(KRQsamples2))],
                                   forest, forest_bins)
## Spatial
SPL_bin_elev <- get_binned_resid(SPLsamples2[iter_subset, grep('\\<p\\[', colnames(SPLsamples2))],
                                 elev, elev_bins)
SPL_bin_forest <- get_binned_resid(SPLsamples2[iter_subset, grep('\\<p\\[', colnames(SPLsamples2))],
                                   forest, forest_bins)
##
SPQ_bin_elev <- get_binned_resid(SPQsamples2[iter_subset, grep('\\<p\\[', colnames(SPQsamples2))],
                                 elev, elev_bins)
SPQ_bin_forest <- get_binned_resid(SPQsamples2[iter_subset, grep('\\<p\\[', colnames(SPQsamples2))],
                                   forest, forest_bins)
## device ----
pdf(file = "../fig/partial_residuals.pdf", width = 8.5, height = 11)
## partial residual boxplots ----
layout(matrix(1:14, 7, 2, byrow = T))
par(mar = c(1, 4, 1, 0.1), oma = c(3, 2, 0, 0))
## naive
boxplot(bin_elev$bin_resids ~ bin_elev$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Elevation (m)", ylab = "residual", xaxt = "n", col = model_colors[7])
mtext("Naive", 2, 4.7)
abline(h = 0, lty = 2, col = "gray")
boxplot(bin_forest$bin_resids ~ bin_forest$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Forest cover (%))", ylab = "", xaxt = "n", col = model_colors[7])
abline(h = 0, lty = 2, col = "gray")
## Poisson
boxplot(PL_bin_elev$bin_resids ~ PL_bin_elev$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Elevation (m)", ylab = "residual", xaxt = "n", col = model_colors[1])
mtext("PL", 2, 4.7)
abline(h = 0, lty = 2, col = "gray")
boxplot(PL_bin_forest$bin_resids ~ PL_bin_forest$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Forest cover (%))", ylab = "", xaxt = "n", col = model_colors[1])
abline(h = 0, lty = 2, col = "gray")
boxplot(PQ_bin_elev$bin_resids ~ PQ_bin_elev$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Elevation (m)", ylab = "residual", xaxt = "n", col = model_colors[2])
mtext("PQ", 2, 4.7)
abline(h = 0, lty = 2, col = "gray")
boxplot(PQ_bin_forest$bin_resids ~ PQ_bin_forest$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Forest cover (%))", ylab = "", xaxt = "n", col = model_colors[2])
abline(h = 0, lty = 2, col = "gray")
## KR
boxplot(KRL_bin_elev$bin_resids ~ KRL_bin_elev$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Elevation (m)", ylab = "residual", xaxt = "n", col = model_colors[3])
mtext("KRL", 2, 4.7)
abline(h = 0, lty = 2, col = "gray")
boxplot(KRL_bin_forest$bin_resids ~ KRL_bin_forest$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Forest cover (%))", ylab = "", xaxt = "n", col = model_colors[3])
abline(h = 0, lty = 2, col = "gray")
boxplot(KRQ_bin_elev$bin_resids ~ KRQ_bin_elev$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Elevation (m)", ylab = "residual", xaxt = "n", col = model_colors[4])
mtext("KRQ", 2, 4.7)
abline(h = 0, lty = 2, col = "gray")
boxplot(KRQ_bin_forest$bin_resids ~ KRQ_bin_forest$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Forest cover (%))", ylab = "", xaxt = "n", col = model_colors[4])
abline(h = 0, lty = 2, col = "gray")
## spatial
boxplot(SPL_bin_elev$bin_resids ~ SPL_bin_elev$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Elevation (m)", ylab = "residual", xaxt = "n", col = model_colors[5])
abline(h = 0, lty = 2, col = "gray")
mtext("SPL", 2, 4.7)
boxplot(SPL_bin_forest$bin_resids ~ SPL_bin_forest$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Forest cover (%))", ylab = "", xaxt = "n", col = model_colors[5])
abline(h = 0, lty = 2, col = "gray")
boxplot(SPQ_bin_elev$bin_resids ~ SPQ_bin_elev$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Elevation (m)", ylab = "residual", col = model_colors[6])
mtext("SPQ", 2, 4.7)
mtext("elevation", 1, 3)
abline(h = 0, lty = 2, col = "gray")
boxplot(SPQ_bin_forest$bin_resids ~ SPQ_bin_forest$bin_centers, ylim = c(-0.15, 0.13),
        xlab = "Forest cover (%))", ylab = "", col = model_colors[6])
mtext("forest cover", 1, 3)
abline(h = 0, lty = 2, col = "gray")
## dev.off ----
dev.off()
