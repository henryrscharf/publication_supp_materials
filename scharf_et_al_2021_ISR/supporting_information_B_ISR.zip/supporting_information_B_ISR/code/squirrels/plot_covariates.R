## libraries ----
library(nimble); library(Matrix); library(raster); library(deldir)
## load squirrel data ----
squirrels <- read.table(file = "../data/squirrels/SwissSquirrels.txt", header = T)
load(file = "../data/squirrels/Switzerland.RData")
N <- nrow(squirrels)
J <- 3
elev <- squirrels[, 'ele']
forest <- squirrels[, 'forest']
date <- as.matrix(squirrels[, paste0('date07', 1:3)])
dur <- as.matrix(squirrels[, paste0('dur07', 1:3)])
for(j in 1:J){
  date[is.na(date[, j]), j] <- mean(date[, j], na.rm = T)
}
dur[is.na(dur)] <- mean(dur, na.rm = T)
## define neighborhood via Delauney method [SP] ----
adj_ind <- deldir(x = squirrels$coordx, y = squirrels$coordy)$delsgs[, c('ind1', 'ind2')]
adj_mat <- matrix(0, nrow(squirrels), nrow(squirrels))
adj_mat[(adj_ind[, 1] - 1) * nrow(squirrels) + adj_ind[, 2]] <- 1
adj_mat <- adj_mat + t(adj_mat)
nimble_car <- as.carAdjacency(adj_mat)
## ----
## device ----
res <- 2
png(filename = "../fig/squirrels_covariates.png", width = 480 * 2 * res, height = 480 * res)
## plot covariates ----
layout(matrix(1:2, 1, 2, byrow = T))
par(mar = c(1, 1, 2.5, 2), bg = NA)
reds = c(0.760784, 0.529412, 0.858824, 1.000000,
         0.666667, 0.494118, 0.360784)
greens = c(0.800000, 0.509804, 0.623529, 0.945098,
           0.901961, 0.741176, 0.572549)
blues = c(0.721569, 0.447059, 0.352941, 0.580392,
          0.670588, 0.768627, 0.800000)
plot(Switzerland[, c('x', 'y')], asp = 1,
     col = rgb(colorRamp(rev(rgb(reds, greens, blues)))(Switzerland$elevation / 5e3),
       maxColorValue = 255), axes = F, xlab = "", ylab = "", cex.lab = 1.5 * res, cex.main = res * 2,
     main = "Elevation", cex = 0.5 * res, pch = 15)
points(squirrels[, c('coordx', 'coordy')], asp = 1,
     col = "dimgray", pch = 15, cex = 0.7 * res)
legend("bottom", horiz = T, fill = rgb(colorRamp(rev(rgb(reds, greens, blues)))(
  pretty(Switzerland$elevation) / 5e3), maxColorValue = 255),
  legend = pretty(Switzerland$elevation), bty = "n", border = NA,
  y.intersp = 0.75, cex = res, pt.cex = res)
# par(xpd = T)
# SDMTools::legend.gradient(pnts = cbind(c(1280000, 1290000, 1290000, 1280000),
#                                        c(98927.76, 98927.76, 226015.22, 226015.22)),
#                                        cols = rev(rgb(reds, greens, blues)),
#                           title = "", limits = c(0, 5000))

plot(Switzerland[, c('x', 'y')], asp = 1,
     col = rgb(colorRamp(RColorBrewer::brewer.pal(9, "Greens")[-1])(Switzerland$forest/100),
               maxColorValue = 255),
     axes = F, xlab = "", ylab = "", main = "Forest", cex.main = res * 2,
     cex.lab = 1.5 * res, cex = 0.5 * res, pch = 15)
points(squirrels[, c('coordx', 'coordy')], asp = 1,
       col = "dimgray", bg = NA, pch = 15, cex = 0.7 * res)
legend("bottom", horiz = T, fill = rgb(
  colorRamp(RColorBrewer::brewer.pal(9, "Greens")[-1])(seq(0, 1, l = 5)),
  maxColorValue = 255), border = NA, y.intersp = 0.75, cex = res,
  pt.cex = res, legend = paste0(seq(0, 100, l = 5), "%"), bty = "n")
## dev.off ----
dev.off()
