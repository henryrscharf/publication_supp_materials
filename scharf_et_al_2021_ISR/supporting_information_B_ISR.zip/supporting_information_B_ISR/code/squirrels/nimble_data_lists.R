## libraries ----
library(nimble); library(Matrix); library(raster); library(deldir)
## load squirrel data ----
squirrels <- read.table(file = "../data/squirrels/SwissSquirrels.txt", header = T)
N <- nrow(squirrels)
J <- 3
elev <- squirrels[, 'ele']
forest <- squirrels[, 'forest']
date <- as.matrix(squirrels[, paste0('date07', 1:3)])
dur <- as.matrix(squirrels[, paste0('dur07', 1:3)])
for(j in 1:J){
  date[is.na(date[, j]), j] <- mean(date[, j], na.rm = T)
}
dur[is.na(dur)] <- mean(dur, na.rm = T)
## define neighborhood via Delauney method [SP] ----
adj_ind <- deldir(x = squirrels$coordx, y = squirrels$coordy)$delsgs[, c('ind1', 'ind2')]
adj_mat <- matrix(0, nrow(squirrels), nrow(squirrels))
adj_mat[(adj_ind[, 1] - 1) * nrow(squirrels) + adj_ind[, 2]] <- 1
adj_mat <- adj_mat + t(adj_mat)
nimble_car <- as.carAdjacency(adj_mat)
## naive [N] ----
Ndata <- list(
  y = as.matrix(squirrels[, paste0('det07', 1:3)])
)
## linear effects only [L] ----
X_beta <- cbind(1, elev, forest)
colnames(X_beta) <- c("intercept", "elevation", "forest")
p_beta <- ncol(X_beta)
## orthogonolize
X_beta_svd <- svd(X_beta)
L_A_beta <- X_beta_svd$v %*% diag(1/X_beta_svd$d)
X_beta_ortho <- X_beta_svd$u
##
X_alpha <- abind::abind(matrix(1, N, J), date, dur, along = 3)
p_alpha <- dim(X_alpha)[3]
## orthogonolize
X_alpha_mat <- matrix(X_alpha, ncol = p_alpha)
colnames(X_alpha_mat) <- c("intercept", "date", "duration")
X_alpha_svd <- svd(X_alpha_mat)
L_A_alpha <- X_alpha_svd$v %*% diag(1/X_alpha_svd$d)
X_alpha_ortho <- array(X_alpha_svd$u, dim = c(N, J, p_alpha))
##
Ldata <- list(
  y = as.matrix(squirrels[, paste0('det07', 1:3)]),
  X_beta = X_beta_ortho,
  X_alpha = X_alpha_ortho
)
## quadratic effects [Q] ----
X_beta <- cbind(1, elev, forest, elev^2, forest^2,
                elev * forest, elev^2 * forest, elev * forest^2)
colnames(X_beta) <- c("intercept", "elevation", "forest",
                      "elevation_sq", "forest_sq",
                      "elevation:forest",
                      "elevation_sq:forest", "elevation:forest_sq"
)
p_beta <- ncol(X_beta)
## orthogonolize
X_beta_svd <- svd(X_beta)
Q_A_beta <- X_beta_svd$v %*% diag(1/X_beta_svd$d)
X_beta_ortho <- X_beta_svd$u
##
X_alpha <- abind::abind(matrix(1, N, J), date, dur, dur^2, along = 3)
p_alpha <- dim(X_alpha)[3]
## orthogonolize
X_alpha_mat <- matrix(X_alpha, ncol = p_alpha)
colnames(X_alpha_mat) <- c("intercept", "date", "duration", "duration_sq")
X_alpha_svd <- svd(X_alpha_mat)
Q_A_alpha <- X_alpha_svd$v %*% diag(1/X_alpha_svd$d)
X_alpha_ortho <- array(X_alpha_svd$u, dim = c(N, J, p_alpha))
##
Qdata <- list(
  y = as.matrix(squirrels[, paste0('det07', 1:3)]),
  X_beta = X_beta_ortho,
  X_alpha = X_alpha_ortho
)

## ----
## constants + inits (priors) ----
## naive [N] ----
Nconstants <- list(N = N, J = J, a_psi = 1, b_psi = 1, a_r = 1, b_r = 1)
Ninits <- list(r = 0.5, psi = 0.5, z = as.numeric(rowSums(Ldata$y, na.rm = T) > 0))
## linear effects only [L] ----
Lconstants <- list(N = N, J = J, p_beta = ncol(Ldata$X_beta), p_alpha = dim(Ldata$X_alpha)[3],
                   var_beta = N / ncol(Ldata$X_beta), var_alpha = N / dim(Ldata$X_alpha)[3])
Linits <- list(beta = rep(0, ncol(Ldata$X_beta)), alpha = rep(0, dim(Ldata$X_alpha)[3]))
## quadratic effects [Q] ----
Qconstants <- list(N = N, J = J, p_beta = ncol(Qdata$X_beta), p_alpha = dim(Qdata$X_alpha)[3],
                    var_beta = N / ncol(Qdata$X_beta), var_alpha = N / dim(Qdata$X_alpha)[3])
Qinits <- list(beta = rep(0, ncol(Qdata$X_beta)), alpha = rep(0, dim(Qdata$X_alpha)[3]))
## spatial [SPL\Q] ----
SPLconstants <- Lconstants; SPQconstants <- Qconstants
SPLconstants$adj <- SPQconstants$adj <- nimble_car$adj
SPLconstants$num <- SPQconstants$num <- nimble_car$num
SPLconstants$a_tau <- SPQconstants$a_tau <- 1
SPLconstants$b_tau <- SPQconstants$b_tau <- 1
SPLconstants$edges <- SPQconstants$edges <- length(nimble_car$adj)
SPLinits <- Linits; SPQinits <- Qinits
SPLinits$tau <- SPQinits$tau <- 1
SPLinits$eta <- SPQinits$eta <-  rep(0, N)
