################# ----
## PRELIMINARY ## ----
################# ----
## libraries ----
library(nimble); library(Matrix); library(raster)
## squirrel data ----
squirrels <- read.table(file = "../data/squirrels/SwissSquirrels.txt", header = T)
N <- nrow(squirrels)
J <- 3
## nimble model code[N, P, KR, SP] ----
source("squirrels/nimble_models.R")
## data lists [N, L, Q] ----
source("squirrels/nimble_data_lists.R")
## create model objects [PL\Q] ----
Lconst_scaled <- Lconstants
Lconst_scaled$var_beta <- 0.5 * Lconstants$var_beta
Lconst_scaled$var_alpha <- 0.5 * Lconstants$var_alpha
Qconst_scaled <- Qconstants
Qconst_scaled$var_beta <- 0.5 * Qconstants$var_beta
Qconst_scaled$var_alpha <- 0.5 * Qconstants$var_alpha
PLmodel <- nimbleModel(code = Pcode, constants = Lconst_scaled,
                       data = Ldata, inits = Linits, check = T)
PLmcmcConf <- configureMCMC(PLmodel)
PLmcmcConf$addMonitors2('p')
PLmcmc <- buildMCMC(PLmcmcConf)
##
PQmodel <- nimbleModel(code = Pcode, constants = Qconst_scaled,
                       data = Qdata, inits = Qinits, check = T)
PQmcmcConf <- configureMCMC(PQmodel)
PQmcmcConf$addMonitors2('p')
PQmcmc <- buildMCMC(PQmcmcConf)
## compile objects [PL\Q] ----
CPLmodel <- compileNimble(PLmodel)
CPLmcmc <- compileNimble(PLmcmc, project = PLmodel)
##
CPQmodel <- compileNimble(PQmodel)
CPQmcmc <- compileNimble(PQmcmc, project = PQmodel)
## N_iterations + fit ----
N_iterations <- 5e4
CPLmcmc$run(N_iterations, nburnin = N_iterations / 2)
PLsamples <- as.matrix(CPLmcmc$mvSamples)
PLsamples_transformed <- PLsamples %*% Matrix::bdiag(t(L_A_alpha), t(L_A_beta))
PLsamples2 <- as.matrix(CPLmcmc$mvSamples2)
colnames(PLsamples_transformed) <- colnames(PLsamples)
##
CPQmcmc$run(N_iterations, nburnin = N_iterations / 2)
PQsamples <- as.matrix(CPQmcmc$mvSamples)
PQsamples_transformed <- PQsamples %*% Matrix::bdiag(t(Q_A_alpha), t(Q_A_beta))
PQsamples2 <- as.matrix(CPQmcmc$mvSamples2)
colnames(PQsamples_transformed) <- colnames(PQsamples)
## save chains ----
save(PLsamples_transformed, PLsamples, PLsamples2,
     PQsamples_transformed, PQsamples, PQsamples2, file = "../data/squirrels/poisson_fit.RData")
## load chains ----
load(file = "../data/squirrels/poisson_fit.RData")
## ----
## device ----
pdf(file = "../fig/squirrels_diagnostics_P.pdf", width = 8, height = 7)
## plot traces [PL] ----
used_iterations <- seq(N_iterations / 2 + 1, N_iterations, 1)
layout(matrix(1:2, 2, 1))
matplot(used_iterations, PLsamples[, grep('beta', colnames(PLsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(beta[svd]), xlab = "")
abline(h = 0, lty = 2)
matplot(used_iterations, PLsamples[, grep('alpha', colnames(PLsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(alpha[svd]), xlab = "")
abline(h = 0, lty = 2)
## plot traces [PQ] ----
used_iterations <- seq(N_iterations / 2 + 1, N_iterations, 1)
layout(matrix(1:2, 2, 1))
matplot(used_iterations, PQsamples[, grep('beta', colnames(PQsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(beta[svd]), xlab = "")
abline(h = 0, lty = 2)
matplot(used_iterations, PQsamples[, grep('alpha', colnames(PQsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(alpha[svd]), xlab = "")
abline(h = 0, lty = 2)
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_effects_PL.pdf", width = 8, height = 7)
## calc effects [PL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- exp(X_elevation %*% t(PLsamples_transformed[, grep('beta', colnames(PLsamples_transformed))]))
pr_elevation <- t(apply(1 - exp(-lambda_elevation_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- exp(X_forest %*% t(PLsamples_transformed[, grep('beta', colnames(PLsamples_transformed))]))
pr_forest <- t(apply(1 - exp(-lambda_forest_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
probit_pr_date_iter <- X_date %*% t(PLsamples_transformed[, grep('alpha', colnames(PLsamples_transformed))])
pr_date <- t(apply(pnorm(as.matrix(probit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
probit_pr_duration_iter <- X_duration %*% t(PLsamples_transformed[, grep('alpha', colnames(PLsamples_transformed))])
pr_duration <- t(apply(pnorm(as.matrix(probit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## plot effects [PL] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values, pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1, las = 1,
        ylab = "Pred. occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values, pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1, las = 1,
        ylab = "Pred. occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values, pr_date, type = "l", lty = 1, col = line_colors,
        lwd = lwds, ylim = 0:1, las = 1,
        ylab = "Pred. detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values, pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1, las = 1,
        ylab = "Pred. detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curve - PL", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_grad_effects_PL.pdf", width = 8, height = 7)
## calc grad effects [PL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- exp(X_elevation %*% t(PLsamples_transformed[, grep('beta', colnames(PLsamples_transformed))]))
grad_pr_elevation <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    (PLsamples_transformed[, grep('beta\\[2\\]', colnames(PLsamples_transformed))]),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- exp(X_forest %*% t(PLsamples_transformed[, grep('beta', colnames(PLsamples_transformed))]))
grad_pr_forest <- t(apply(
  t(exp(-lambda_forest_iter) * lambda_forest_iter) *
    (PLsamples_transformed[, grep('beta\\[3\\]', colnames(PLsamples_transformed))]),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
probit_pr_date_iter <- X_date %*% t(PLsamples_transformed[, grep('alpha', colnames(PLsamples_transformed))])
grad_pr_date <- t(apply(
  t(dnorm(as.matrix(probit_pr_date_iter))) *
    PLsamples_transformed[, grep('alpha\\[2\\]', colnames(PLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
probit_pr_duration_iter <- X_duration %*% t(PLsamples_transformed[, grep('alpha', colnames(PLsamples_transformed))])
grad_pr_duration <- t(apply(
  t(dnorm(as.matrix(probit_pr_duration_iter))) *
    PLsamples_transformed[, grep('alpha\\[3\\]', colnames(PLsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## plot grad effects [PL] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values, 1e2 * grad_pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values, 10 * grad_pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values, 14 * grad_pr_date, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values, 60 * grad_pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curve gradients - PL", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_effects_PQ.pdf", width = 8, height = 7)
## calc effects [PQ] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- exp(X_elevation %*% t(PQsamples_transformed[, grep('beta', colnames(PQsamples_transformed))]))
pr_elevation <- t(apply(1 - exp(-lambda_elevation_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- exp(X_forest %*% t(PQsamples_transformed[, grep('beta', colnames(PQsamples_transformed))]))
pr_forest <- t(apply(1 - exp(-lambda_forest_iter), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
probit_pr_date_iter <- X_date %*% t(PQsamples_transformed[, grep('alpha', colnames(PQsamples_transformed))])
pr_date <- t(apply(pnorm(as.matrix(probit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
probit_pr_duration_iter <- X_duration %*% t(PQsamples_transformed[, grep('alpha', colnames(PQsamples_transformed))])
pr_duration <- t(apply(pnorm(as.matrix(probit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## plot effects [PQ] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values, pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1, las = 1,
        ylab = "Pred. occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values, pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1,
        ylab = "Pred. occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values, pr_date, type = "l", lty = 1, col = line_colors,
        lwd = lwds, ylim = 0:1,
        ylab = "Pred. detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values, pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1,
        ylab = "Pred. detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curve - PQ", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_grad_effects_PQ.pdf", width = 8, height = 7)
## calc grad effects [PQ] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- exp(X_elevation %*% t(PQsamples_transformed[, grep('beta', colnames(PQsamples_transformed))]))
grad_pr_elevation <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    (PQsamples_transformed[, grep('beta\\[2\\]', colnames(PQsamples_transformed))] +
       2 * t(elev_values %o% PQsamples_transformed[, grep('beta\\[4\\]', colnames(PQsamples_transformed))]) +
       forest_value * PQsamples_transformed[, grep('beta\\[6\\]', colnames(PQsamples_transformed))] +
       2 * forest_value * t(elev_values %o% PQsamples_transformed[, grep('beta\\[7\\]', colnames(PQsamples_transformed))]) +
       forest_value^2 * PQsamples_transformed[, grep('beta\\[8\\]', colnames(PQsamples_transformed))]),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- exp(X_forest %*% t(PQsamples_transformed[, grep('beta', colnames(PQsamples_transformed))]))
grad_pr_forest <- t(apply(
  t(exp(-lambda_elevation_iter) * lambda_elevation_iter) *
    (PQsamples_transformed[, grep('beta\\[3\\]', colnames(PQsamples_transformed))] +
       2 * t(forest_values %o% PQsamples_transformed[, grep('beta\\[5\\]', colnames(PQsamples_transformed))]) +
       elev_value * PQsamples_transformed[, grep('beta\\[6\\]', colnames(PQsamples_transformed))] +
       elev_value^2 * PQsamples_transformed[, grep('beta\\[7\\]', colnames(PQsamples_transformed))] +
       2 * elev_value * t(forest_values %o% PQsamples_transformed[, grep('beta\\[8\\]', colnames(PQsamples_transformed))])),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
probit_pr_date_iter <- X_date %*% t(PQsamples_transformed[, grep('alpha', colnames(PQsamples_transformed))])
grad_pr_date <- t(apply(
  t(dnorm(as.matrix(probit_pr_date_iter))) *
    PQsamples_transformed[, grep('alpha\\[2\\]', colnames(PQsamples_transformed))],
  2, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
probit_pr_duration_iter <- X_duration %*% t(PQsamples_transformed[, grep('alpha', colnames(PQsamples_transformed))])
grad_pr_duration <- t(apply(
  t(dnorm(as.matrix(probit_pr_duration_iter))) *
    (PQsamples_transformed[, grep('alpha\\[3\\]', colnames(PQsamples_transformed))] +
       2 * t(dur_values %o% PQsamples_transformed[, grep('alpha\\[4\\]', colnames(PQsamples_transformed))])),
  2, quantile, probs = c(0.025, 0.5, 0.975)))
## plot grad effects [PQ] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values, 1e2 * grad_pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values, 10 * grad_pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values, 14 * grad_pr_date, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values, 60 * grad_pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curve gradients - PQ", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
# ## ESS ----
# coda::effectiveSize(coda::mcmc(PLsamples[, grep('alpha|beta', colnames(PLsamples))]))
# coda::effectiveSize(coda::mcmc(PQsamples[, grep('alpha|beta', colnames(PQsamples))]))
## ----
## maps ----
load(file = "../data/squirrels/Switzerland.RData")
blocks <- matrix(1:nrow(Switzerland), ncol = 25)
# ## KR colors
# map_colors <- c("grey", "yellow", "orange", "red")
## my colors
# map_colors <- rev(RSciVisColor::scivis.pal("green_1"))
map_colors <- c("gray92", "gray1")
## predict at each location [PL] (~3min) ----
PL_pr_Switzerland <- NULL
PL_lambda_Switzerland <- NULL
system.time({
  for(b in 1:ncol(blocks)){
    X_Switzerland <- as.matrix(cbind(1, Switzerland[blocks[, b], c('elevation', 'forest')]))
    lambda_Switzerland_iter <- exp(X_Switzerland %*% t(PLsamples_transformed[, 4:6]))
    PL_pr_Switzerland <-
      rbind(PL_pr_Switzerland, t(apply(1 - exp(-lambda_Switzerland_iter), 1,
                                                quantile, probs = c(0.025, 0.5, 0.975))))
    PL_lambda_Switzerland <-
      rbind(PL_lambda_Switzerland,
            t(apply(lambda_Switzerland_iter, 1, quantile, probs = c(0.025, 0.5, 0.975))))
    rm(lambda_Switzerland_iter)
    gc()
  }
})
## predict at each location [PQ] (~3min) ----
PQ_pr_Switzerland <- NULL
PQ_lambda_Switzerland <- NULL
system.time({
  for(b in 1:ncol(blocks)){
    X_Switzerland <- as.matrix(cbind(1, Switzerland[blocks[, b], c('elevation', 'forest')],
                                     Switzerland[blocks[, b], c('elevation', 'forest')]^2,
                                     Switzerland[blocks[, b], 'elevation'] *
                                       Switzerland[blocks[, b], 'forest'],
                                     Switzerland[blocks[, b], 'elevation']^2 *
                                       Switzerland[blocks[, b], 'forest'],
                                     Switzerland[blocks[, b], 'elevation'] *
                                       Switzerland[blocks[, b], 'forest']^2))
    lambda_Switzerland_iter <- exp(X_Switzerland %*% t(PQsamples_transformed[, 5:12]))
    PQ_pr_Switzerland <-
      rbind(PQ_pr_Switzerland, t(apply(1 - exp(-lambda_Switzerland_iter), 1,
                                                quantile, probs = c(0.025, 0.5, 0.975))))
    PQ_lambda_Switzerland <-
      rbind(PQ_lambda_Switzerland,
            t(apply(lambda_Switzerland_iter, 1, quantile, probs = c(0.025, 0.5, 0.975))))
    rm(lambda_Switzerland_iter)
    gc()
  }
})
## device ----
pdf("../fig/squirrels_map_PL.pdf")
## rasterize + plot [PL] ----
PL_pr_raster <- rasterFromXYZ(xyz = cbind(Switzerland[, c('x', 'y')], PL_pr_Switzerland))
elev <- rasterFromXYZ(Switzerland[, c('x', 'y', 'elevation')])
elev[elev > 2250] <- NA
PL_pr_raster <- mask(PL_pr_raster, elev)
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
plot(PL_pr_raster[[2]], col = colorRampPalette(map_colors)(1e2),
     box = F, axes = F, zlim = 0:1, main = 'Poisson - Linear')
plot(water_raster > 0, add = T, col = "lightblue", legend = F)
## dev.off ----
dev.off()
## device ----
pdf("../fig/squirrels_map_PQ.pdf")
## rasterize + plot [PQ] ----
PQ_pr_raster <- rasterFromXYZ(xyz = cbind(Switzerland[, c('x', 'y')], PQ_pr_Switzerland))
elev <- rasterFromXYZ(Switzerland[, c('x', 'y', 'elevation')])
elev[elev > 2250] <- NA
PQ_pr_raster <- mask(PQ_pr_raster, elev)
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
plot(PQ_pr_raster[[2]], col = colorRampPalette(map_colors)(1e2),
     box = F, axes = F, zlim = 0:1, main = 'Poisson - Quadratic')
plot(water_raster > 0, add = T, col = "lightblue", legend = F)
## dev.off ----
dev.off()

## device ----
pdf("../fig/squirrels_map_lambda_PL.pdf")
## rasterize + plot lambda [PL] ----
PL_lambda_raster <- rasterFromXYZ(xyz = cbind(Switzerland[, c('x', 'y')], PL_lambda_Switzerland))
elev <- rasterFromXYZ(Switzerland[, c('x', 'y', 'elevation')])
elev[elev > 2250] <- NA
PL_lambda_raster <- mask(PL_lambda_raster, elev)
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
plot(PL_lambda_raster[[2]], col = colorRampPalette(map_colors)(1e2),
     box = F, axes = F, zlim = c(0, 26), main = 'Expected counts - Linear')
plot(water_raster > 0, add = T, col = "lightblue", legend = F)
## dev.off ----
dev.off()

## device ----
pdf("../fig/squirrels_map_lambda_PQ.pdf")
## rasterize + plot lambda [PQ] ----
PQ_lambda_raster <- rasterFromXYZ(xyz = cbind(Switzerland[, c('x', 'y')], PQ_lambda_Switzerland))
elev <- rasterFromXYZ(Switzerland[, c('x', 'y', 'elevation')])
elev[elev > 2250] <- NA
PQ_lambda_raster <- mask(PQ_lambda_raster, elev)
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
plot(PQ_lambda_raster[[2]], col = colorRampPalette(map_colors)(1e2),
     box = F, axes = F, zlim = c(0, 26), main = 'Expected counts - Quadratic')
plot(water_raster > 0, add = T, col = "lightblue", legend = F)
## dev.off ----
dev.off()

## device ----
pdf("../fig/squirrels_map_lambda_PL_PQ.pdf", height = 2.6, width = 8)
## layout ----
layout(matrix(1:2, 1, 2), widths = c(1, 1))
## rasterize + plot lambda [PL] ----
par(mar = c(0, 0.5, 1.1, 0.5))
PL_lambda_raster <- rasterFromXYZ(xyz = cbind(Switzerland[, c('x', 'y')], PL_lambda_Switzerland))
elev <- rasterFromXYZ(Switzerland[, c('x', 'y', 'elevation')])
elev[elev > 2250] <- NA
PL_lambda_raster <- mask(PL_lambda_raster, elev)
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
plot(PL_lambda_raster[[2]], col = colorRampPalette(map_colors)(1e2), asp = 1,
     box = F, axes = F, zlim = c(0, 26), main = 'Linear', legend = F)
plot(water_raster > 0, add = T, col = "lightblue", legend = F, asp = 1)
## rasterize + plot lambda [PQ] ----
par(mar = c(0, 0, 1.1, 3.1))
PQ_lambda_raster <- rasterFromXYZ(xyz = cbind(Switzerland[, c('x', 'y')], PQ_lambda_Switzerland))
elev <- rasterFromXYZ(Switzerland[, c('x', 'y', 'elevation')])
elev[elev > 2250] <- NA
PQ_lambda_raster <- mask(PQ_lambda_raster, elev)
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
plot(PQ_lambda_raster[[2]], col = colorRampPalette(map_colors)(1e2), asp = 1,
     box = F, axes = F, zlim = c(0, 26), main = 'Quadratic')
plot(water_raster > 0, add = T, col = "lightblue", legend = F, asp = 1)
## dev.off ----
dev.off()
