## prep variables ----
source("squirrels/adaptive/prep.R")
## make storage variables + loop over adaptive prior ----
CV_SPQ <- matrix(NA, k, length(scales))
rownames(CV_SPQ) <- 1:k
colnames(CV_SPQ) <- scales
SPQconst_scaled <- SPQconstants
for(scale in scales){
  message("scale = ", scale, "\n",
          "time = ", Sys.time())
  scale_ind <- which(scale == scales)
  ## constants ----
  SPQconst_scaled$var_beta <- scale * SPQconstants$var_beta
  SPQconst_scaled$var_alpha <- scale * SPQconstants$var_alpha
  ## create our spatial model object [SPQ] ----
  SPQmodel <- nimbleModel(code = SPcode, constants = SPQconst_scaled,
                          data = Qdata, inits = SPQinits)
  SPQmcmcConf <- configureMCMC(SPQmodel)
  SPQmcmc <- buildMCMC(SPQmcmcConf)
  ## k-fold CV ----
  system.time({
    CV_SPQ[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = SPQmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
}
## ----
## save scores ----
save(CV_SPQ, file = "../data/squirrels/CV_SPQ_adaptive.RData")
