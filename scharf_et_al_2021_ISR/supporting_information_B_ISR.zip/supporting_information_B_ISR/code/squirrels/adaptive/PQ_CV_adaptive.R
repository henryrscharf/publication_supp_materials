## prep variables ----
source("squirrels/adaptive/prep.R")
## make storage variables + loop over adaptive prior ----
CV_PQ <- matrix(NA, k, length(scales))
rownames(CV_PQ) <- 1:k
colnames(CV_PQ) <- scales
Qconst_scaled <- Qconstants
for(scale in scales){
  message("scale = ", scale, "\n",
          "time = ", Sys.time())
  scale_ind <- which(scale == scales)
  ## constants ----
  Qconst_scaled$var_beta <- scale * Qconstants$var_beta
  Qconst_scaled$var_alpha <- scale * Qconstants$var_alpha
  ## create model object [PQ] ----
  PQmodel <- nimbleModel(code = Pcode, constants = Qconst_scaled,
                         data = Qdata, inits = Qinits)
  PQmcmcConf <- configureMCMC(PQmodel)
  PQmcmc <- buildMCMC(PQmcmcConf)
  ## k-fold CV [PQ] ----
  system.time({
    CV_PQ[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = PQmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
}
## ----
## save scores ----
save(CV_PQ, file = "../data/squirrels/CV_PQ_adaptive.RData")
