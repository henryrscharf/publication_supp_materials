## libraries ----
library(latex2exp)
## load scores ----
load("../data/squirrels/CV_N.RData")
models <- c("PL", "PQ", "KRL", "KRQ", "SPL", "SPQ", "N")
for(model in models[-7]){
  load(paste0("../data/squirrels/CV_", model, "_adaptive.RData"))
}
k <- length(CV_N)
scales <- as.numeric(colnames(CV_PL))
## optimal score summary ----
opt_ind <- c(PL = as.integer(which.min(colMeans(CV_PL))),
             PQ = as.integer(which.min(colMeans(CV_PQ))),
             KRL = as.integer(which.min(colMeans(CV_KRL))),
             KRQ = as.integer(which.min(colMeans(CV_KRQ))),
             SPL = as.integer(which.min(colMeans(CV_SPL))),
             SPQ = as.integer(which.min(colMeans(CV_SPQ))))
CV_CI <- cbind(
  mean(CV_PL[, opt_ind['PL']]) + 1.96 * c(-1, 1) * sd(CV_PL[, opt_ind['PL']]) / sqrt(k - 1),
  mean(CV_PQ[, opt_ind['PQ']]) + 1.96 * c(-1, 1) * sd(CV_PQ[, opt_ind['PQ']]) / sqrt(k - 1),
  mean(CV_KRL[, opt_ind['KRL']]) + 1.96 * c(-1, 1) * sd(CV_KRL[, opt_ind['KRL']]) / sqrt(k - 1),
  mean(CV_KRQ[, opt_ind['KRQ']]) + 1.96 * c(-1, 1) * sd(CV_KRQ[, opt_ind['KRQ']]) / sqrt(k - 1),
  mean(CV_SPL[, opt_ind['SPL']]) + 1.96 * c(-1, 1) * sd(CV_SPL[, opt_ind['SPL']]) / sqrt(k - 1),
  mean(CV_SPQ[, opt_ind['SPQ']]) + 1.96 * c(-1, 1) * sd(CV_SPQ[, opt_ind['SPQ']]) / sqrt(k - 1),
  mean(CV_N) + 1.96 * c(-1, 1) * sd(CV_N) / sqrt(k - 1)
)
model_names <- c("Poisson-L", "Poisson-Q",
                 "Kéry-Royle-L", "Kéry-Royle-Q",
                 "Spatial-L", "Spatial-Q",
                 "Naive")
colnames(CV_CI) <- model_names
rownames(CV_CI) <- c("lower", "upper")
## device scores ----
pdf("../fig/adaptive/squirrels_CV_adapted.pdf", height = 5, width = 8)
## plot scores ----
CV_all <- cbind(CV_PL[, opt_ind['PL']], CV_PQ[, opt_ind['PQ']],
                CV_KRL[, opt_ind['KRL']], CV_KRQ[, opt_ind['KRQ']],
                CV_SPL[, opt_ind['SPL']], CV_SPQ[, opt_ind['SPQ']],
                CV_N)
colnames(CV_all) <- colnames(CV_CI)
colors <- RColorBrewer::brewer.pal(ncol(CV_all), "Dark2")[c(1, 5, 2, 4, 6, 7, 3)]
pchs <- c(1, 5, 3, 4, 2, 6, 7)
names(pchs) <- names(colors) <- models
layout(matrix(1:2, 1, 2), widths = c(1, 0.2))
par(mar = c(4.4, 4.4, 2.1, 1.1))
range(CV_all)
matplot(CV_all, type = "b", lwd = 2,
        xlab = "fold",
        ylab = TeX(r'(score: $S(\mathbf{y}_{s_k}, \hat{\mathbf{p}}_{s_k})$)'),
        pch = pchs, col = colors, bty = "n", lty = 1, ylim = c(0.14, 0.26))
legend(par()$usr[2:1] %*% c(-0.02, 1.02), par()$usr[3:4] %*% c(-0.14, 1.14), xpd = T,
       lwd = 2, pch = pchs, lty = NA, ncol = 4, x.intersp = 0.7,
       col = colors, legend = model_names, bty = "n")
par(mar = c(5.1, 0.1, 4.1, 0.1))
boxplot(CV_all, frame = F, axes = F, ylab = "CV score")
points(1:ncol(CV_all), rep(par()$usr[3], ncol(CV_all)), pch = pchs, col = colors, lwd = 2, xpd = T)
## dev.off ----
dev.off()
## device ----
pdf("../fig/adaptive/squirrels_CV_adaptive_grid.pdf", height = 5, width = 8)
## plot regularization ----
layout(1)
range(sapply(models[-7], function(x) colMeans(get(paste0("CV_", x)))))
par(mar = c(4.4, 4.4, 2.1, 1.1))
plot(scales, colMeans(CV_PL), log = "x", type = "n", bty = "n",
     ylim = c(0.175, 0.195), ylab = TeX(r'(score: $\bar{S}(\mathbf{y}_{s_k}, \hat{\mathbf{p}}_{s_k})$)'),
     xlab = TeX(r'(scale factor: $\rho$)'))
for(model in models[-7]){
  points(scales, colMeans(get(paste0("CV_", model))), type = "b",
         pch = pchs[model], col = colors[model], lwd = 2, xpd = T)
  points(scales[opt_ind[model]], colMeans(get(paste0("CV_", model)))[opt_ind[model]],
         pch = pchs[model], lwd = 3)
}
legend(0.07, par()$usr[3:4] %*% c(-0.14, 1.14), xpd = T,
       lwd = 2, pch = pchs, lty = NA, ncol = 4, x.intersp = 0.7,
       col = colors, legend = model_names[-7], bty = "n")
## dev.off ----
dev.off()
