## prep variables ----
source("squirrels/adaptive/prep.R")
## create model object [N] ----
Nmodel <- nimbleModel(code = Ncode, constants = Nconstants,
                      data = Ndata, inits = Ninits)
NmcmcConf <- configureMCMC(Nmodel)
Nmcmc <- buildMCMC(NmcmcConf)
## k-fold CV [N] ----
system.time({
  CV_N <- my_runCrossValidate(MCMCconfiguration = NmcmcConf, nCores = n_cores, folds_list = folds_list,
                              MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
})
## save scores ----
save(CV_N, file = "../data/squirrels/CV_N.RData")
