## prep variables ----
source("squirrels/adaptive/prep.R")
## make storage variables + loop over adaptive prior ----
CV_KRL <- matrix(NA, k, length(scales))
rownames(CV_KRL) <- 1:k
colnames(CV_KRL) <- scales
Lconst_scaled <- Lconstants
for(scale in scales){
  message("scale = ", scale, "\n",
          "time = ", Sys.time())
  scale_ind <- which(scale == scales)
  ## constants ----
  Lconst_scaled$var_beta <- scale * Lconstants$var_beta
  Lconst_scaled$var_alpha <- scale * Lconstants$var_alpha
  ## create model object [KRL] ----
  KRLmodel <- nimbleModel(code = KRcode, constants = Lconst_scaled,
                          data = Ldata, inits = Linits)
  KRLmcmcConf <- configureMCMC(KRLmodel)
  KRLmcmc <- buildMCMC(KRLmcmcConf)
  ## k-fold CV [KRL] ----
  system.time({
    CV_KRL[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = KRLmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
}
## ----
## save scores ----
save(CV_KRL, file = "../data/squirrels/CV_KRL_adaptive.RData")
