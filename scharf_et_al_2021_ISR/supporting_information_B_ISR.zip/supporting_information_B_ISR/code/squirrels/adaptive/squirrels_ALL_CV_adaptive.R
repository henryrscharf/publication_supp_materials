################# ----
## PRELIMINARY ## ----
################# ----
## libraries ----
library(nimble); library(Matrix); library(raster)
library(foreach); library(iterators); library(doParallel)
nimbleOptions(check = FALSE, clearNimbleFunctionsAfterCompiling = FALSE)
## squirrel data ----
squirrels <- read.table(file = "../data/squirrels/SwissSquirrels.txt", header = T)
N <- nrow(squirrels)
J <- 3
## folds for CV + adaptive scales + N_iterations ----
set.seed(2017)
k <- 8
scales <- c(0.1, 0.5, 1, 2, 5, 10, 20)
n_cores <- 1
N_iterations <- 5e2
y_vec <- as.matrix(squirrels[, grep('det', colnames(squirrels))])
## observation-wise CV
# folds_ind <- sample(which(!is.na(y_vec)), sum(!is.na(y_vec)))
# folds_list <- apply(matrix(c(folds_ind, rep(NA, k - (length(folds_ind) %% k))), ncol = k, byrow = T), 2, sort)
## site-wise CV
row_folds <- matrix(c(sample(1:N, N), rep(NA, k - N %%k)), ncol = k, byrow = T)
ind_mat <- matrix(1:(N * J), N, J)
ind_mat[is.na(y_vec)] <- NA
folds_list <- apply(row_folds, 2, function(x) sort(c(ind_mat[x, ])))
## my runCrossValidate function ----
my_runCrossValidate <- function(MCMCconfiguration, folds_list,
                                lossFunction = function(simulatedDataValues, actualDataValues){
                                  (simulatedDataValues - actualDataValues)^2
                                },
                                MCMCcontrol = list(niter = 1e2, nburnin = 5e1), nCores = 1){
  require(foreach); require(iterators)
  out <- foreach(fold = iter(folds_list), .combine = "c", .packages = c('nimble')) %do% {
    ## drop fold ----
    model <- MCMCconfiguration$model
    data_fold_dropped <- model$origData
    test_y <- as.numeric(data_fold_dropped$y[fold])
    data_fold_dropped$y[fold] <- NA
    model$setData(data_fold_dropped)
    MCMCconfiguration <- configureMCMC(model)
    MCMCconfiguration$addMonitors2('p')
    mcmc <- buildMCMC(MCMCconfiguration)
    ## compile ----
    Cmodel <- compileNimble(model)
    Cmcmc <- compileNimble(mcmc, project = Cmodel)
    ## N_iterations + fit ----
    Cmcmc$run(MCMCcontrol[["niter"]], nburnin = MCMCcontrol[["nburnin"]])
    samples2 <- as.matrix(Cmcmc$mvSamples2)
    ## compute loss ----
    loss <- as.numeric(mean(lossFunction(t(samples2[, grep('p', colnames(samples2))[fold]]), test_y)))
    ## put data back (for parallelization purposes)
    data_fold_dropped$y[fold] <- test_y
    model$setData(data_fold_dropped)
    return(loss)
  }
  return(out)
}
## nimble model code[N, P, KR, SP] ----
source("squirrels/nimble_models.R")
## data lists [N, L, Q] ----
source("squirrels/nimble_data_lists.R")
####################### ----
## CV for each model ## ----
####################### ----
## create model object [N] ----
Nmodel <- nimbleModel(code = Ncode, constants = Nconstants,
                      data = Ndata, inits = Ninits)
NmcmcConf <- configureMCMC(Nmodel)
Nmcmc <- buildMCMC(NmcmcConf)
## k-fold CV [N] ----
system.time({
  CV_N <- my_runCrossValidate(MCMCconfiguration = NmcmcConf, nCores = n_cores, folds_list = folds_list,
                              MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
})
## ----
## make storage variables + loop over adaptive prior ----
CV_PL <- CV_PQ <- CV_KRL <- CV_KRQ <- CV_SPL <- CV_SPQ <- matrix(NA, k, length(scales))
rownames(CV_PQ) <- rownames(CV_PL) <- rownames(CV_KRL) <- rownames(CV_KRQ) <- 1:k
rownames(CV_SPL) <- rownames(CV_SPQ) <- 1:k
colnames(CV_PQ) <- colnames(CV_PL) <- colnames(CV_KRL) <- colnames(CV_KRQ) <- scales
colnames(CV_SPL) <- colnames(CV_SPQ) <- scales
Lconst_scaled <- Lconstants
Qconst_scaled <- Qconstants
SPLconst_scaled <- SPLconstants
SPQconst_scaled <- SPQconstants
for(scale in scales){
  message("scale = ", scale, "\n",
          "time = ", Sys.time())
  scale_ind <- which(scale == scales)
  ## constants ----
  Lconst_scaled$var_beta <- scale * Lconstants$var_beta
  Lconst_scaled$var_alpha <- scale * Lconstants$var_alpha
  Qconst_scaled$var_beta <- scale * Qconstants$var_beta
  Qconst_scaled$var_alpha <- scale * Qconstants$var_alpha
  SPLconst_scaled$var_beta <- scale * SPLconstants$var_beta
  SPLconst_scaled$var_alpha <- scale * SPLconstants$var_alpha
  SPQconst_scaled$var_beta <- scale * SPQconstants$var_beta
  SPQconst_scaled$var_alpha <- scale * SPQconstants$var_alpha
  ## create model object [PL] ----
  PLmodel <- nimbleModel(code = Pcode, constants = Lconst_scaled,
                         data = Ldata, inits = Linits)
  PLmcmcConf <- configureMCMC(PLmodel)
  PLmcmc <- buildMCMC(PLmcmcConf)
  ## k-fold CV [PL] ----
  system.time({
    CV_PL[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = PLmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
  nimble:::clearCompiled(PLmodel)
  ## ----
  ## create model object [PQ] ----
  PQmodel <- nimbleModel(code = Pcode, constants = Qconst_scaled,
                         data = Qdata, inits = Qinits)
  PQmcmcConf <- configureMCMC(PQmodel)
  PQmcmc <- buildMCMC(PQmcmcConf)
  ## k-fold CV [PQ] ----
  system.time({
    CV_PQ[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = PQmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
  nimble:::clearCompiled(PQmodel)
  ## ----
  ## create model object [KRL] ----
  KRLmodel <- nimbleModel(code = KRcode, constants = Lconst_scaled,
                          data = Ldata, inits = Linits)
  KRLmcmcConf <- configureMCMC(KRLmodel)
  KRLmcmc <- buildMCMC(KRLmcmcConf)
  ## k-fold CV [KRL] ----
  system.time({
    CV_KRL[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = KRLmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
  nimble:::clearCompiled(KRLmodel)
  ## ----
  ## create model object [KRQ] ----
  KRQmodel <- nimbleModel(code = KRcode, constants = Qconst_scaled,
                          data = Qdata, inits = Qinits)
  KRQmcmcConf <- configureMCMC(KRQmodel)
  KRQmcmc <- buildMCMC(KRQmcmcConf)
  ## k-fold CV [KRQ] ----
  system.time({
    CV_KRQ[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = KRQmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
  nimble:::clearCompiled(KRQmodel)
  ## ----
  ## create our spatial model object [SPL] ----
  SPLmodel <- nimbleModel(code = SPcode, constants = SPLconst_scaled,
                          data = Ldata, inits = SPLinits)
  SPLmcmcConf <- configureMCMC(SPLmodel)
  SPLmcmc <- buildMCMC(SPLmcmcConf)
  ## k-fold CV ----
  system.time({
    CV_SPL[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = SPLmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
  nimble:::clearCompiled(SPLmodel)
  ## ----
  ## create our spatial model object [SPQ] ----
  SPQmodel <- nimbleModel(code = SPcode, constants = SPQconst_scaled,
                          data = Qdata, inits = SPQinits)
  SPQmcmcConf <- configureMCMC(SPQmodel)
  SPQmcmc <- buildMCMC(SPQmcmcConf)
  ## k-fold CV ----
  system.time({
    CV_SPQ[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = SPQmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
  nimble:::clearCompiled(SPQmodel)
}
## ----
## save scores ----
save(CV_N, CV_PL, CV_PQ, CV_KRL, CV_KRQ, CV_SPL, CV_SPQ,
     file = "../data/squirrels/CV_scores_adaptive.RData")
# ## load scores ----
# load("../data/squirrels/CV_scores.RData")
# k <- length(CV_N)
## optimal score summary ----
opt_ind <- c(PL = as.integer(which.min(colMeans(CV_PL))),
             PQ = as.integer(which.min(colMeans(CV_PQ))),
             KRL = as.integer(which.min(colMeans(CV_KRL))),
             KRQ = as.integer(which.min(colMeans(CV_KRQ))),
             SPL = as.integer(which.min(colMeans(CV_SPL))),
             SPQ = as.integer(which.min(colMeans(CV_SPQ))))
CV_CI <- cbind(
  mean(CV_PL[, opt_ind['PL']]) + 1.96 * c(-1, 1) * sd(CV_PL[, opt_ind['PL']]) / sqrt(k - 1),
  mean(CV_PQ[, opt_ind['PQ']]) + 1.96 * c(-1, 1) * sd(CV_PQ[, opt_ind['PQ']]) / sqrt(k - 1),
  mean(CV_KRL[, opt_ind['KRL']]) + 1.96 * c(-1, 1) * sd(CV_KRL[, opt_ind['KRL']]) / sqrt(k - 1),
  mean(CV_KRQ[, opt_ind['KRQ']]) + 1.96 * c(-1, 1) * sd(CV_KRQ[, opt_ind['KRQ']]) / sqrt(k - 1),
  mean(CV_SPL[, opt_ind['SPQ']]) + 1.96 * c(-1, 1) * sd(CV_SPL[, opt_ind['SPQ']]) / sqrt(k - 1),
  mean(CV_SPQ[, opt_ind['SPQ']]) + 1.96 * c(-1, 1) * sd(CV_SPQ[, opt_ind['SPQ']]) / sqrt(k - 1),
  mean(CV_N) + 1.96 * c(-1, 1) * sd(CV_N) / sqrt(k - 1)
)
colnames(CV_CI) <- c("Poisson-L", "Poisson-Q",
                     "Kéry-Royle-L", "Kéry-Royle-Q",
                     "Spatial-L", "Spatial-Q",
                     "Naive")
rownames(CV_CI) <- c("lower", "upper")
## device scores ----
pdf("../fig/adaptive/squirrels_CV.pdf", height = 5, width = 8)
## plot scores ----
CV_all <- cbind(CV_PL[, opt_ind['PL']], CV_PQ[, opt_ind['PQ']],
                CV_KRL[, opt_ind['KRL']], CV_KRQ[, opt_ind['KRQ']],
                CV_SPL[, opt_ind['SPL']], CV_SPQ[, opt_ind['SPQ']],
                CV_N)
colnames(CV_all) <- colnames(CV_CI)
colors <- RColorBrewer::brewer.pal(ncol(CV_all), "Dark2")[c(1, 5, 2, 4, 6, 7, 3)]
pchs <- c(1, 5, 3, 4, 2, 6, 7)
layout(matrix(1:2, 1, 2), widths = c(1, 0.2))
par(mar = c(5.1, 4.1, 2.1, 1.1))
matplot(CV_all, type = "b", lwd = 2, xlab = "fold", ylab = "score",
        pch = pchs, col = colors, bty = "n", lty = 1, ylim = c(0.14, 0.22))
legend(par()$usr[1], par()$usr[3:4] %*% c(-0.1, 1.1), xpd = T,
       lwd = 2, pch = pchs, lty = NA, ncol = 4, x.intersp = 0.7,
       col = colors, legend = colnames(CV_all), bty = "n")
par(mar = c(5.1, 0.1, 4.1, 0.1))
boxplot(CV_all, frame = F, axes = F, ylab = "CV score")
points(1:ncol(CV_all), rep(par()$usr[3], ncol(CV_all)), pch = pchs, col = colors, lwd = 2, xpd = T)
# text(x = 1:7, y = par()$usr[3:4] %*% c(1, -0.03), labels = colnames(CV_all), srt = 30, xpd = T)
## dev.off ----
dev.off()
