## prep variables ----
source("squirrels/adaptive/prep.R")
## make storage variables + loop over adaptive prior ----
CV_PL <-  matrix(NA, k, length(scales))
rownames(CV_PL) <- 1:k
colnames(CV_PL) <- scales
Lconst_scaled <- Lconstants
for(scale in scales){
  message("scale = ", scale, "\n",
          "time = ", Sys.time())
  scale_ind <- which(scale == scales)
  ## constants ----
  Lconst_scaled$var_beta <- scale * Lconstants$var_beta
  Lconst_scaled$var_alpha <- scale * Lconstants$var_alpha
  ## create model object [PL] ----
  PLmodel <- nimbleModel(code = Pcode, constants = Lconst_scaled,
                         data = Ldata, inits = Linits)
  PLmcmcConf <- configureMCMC(PLmodel)
  PLmcmc <- buildMCMC(PLmcmcConf)
  ## k-fold CV [PL] ----
  system.time({
    CV_PL[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = PLmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
}
## ----
## save scores ----
save(CV_PL, file = "../data/squirrels/CV_PL_adaptive.RData")
