## prep variables ----
source("squirrels/adaptive/prep.R")
## make storage variables + loop over adaptive prior ----
CV_KRQ <- matrix(NA, k, length(scales))
rownames(CV_KRQ) <- 1:k
colnames(CV_KRQ) <- scales
Qconst_scaled <- Qconstants
for(scale in scales){
  message("scale = ", scale, "\n",
          "time = ", Sys.time())
  scale_ind <- which(scale == scales)
  ## constants ----
  Qconst_scaled$var_beta <- scale * Qconstants$var_beta
  Qconst_scaled$var_alpha <- scale * Qconstants$var_alpha
  ## create model object [KRQ] ----
  KRQmodel <- nimbleModel(code = KRcode, constants = Qconst_scaled,
                          data = Qdata, inits = Qinits)
  KRQmcmcConf <- configureMCMC(KRQmodel)
  KRQmcmc <- buildMCMC(KRQmcmcConf)
  ## k-fold CV [KRQ] ----
  system.time({
    CV_KRQ[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = KRQmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
}
## ----
## save scores ----
save(CV_KRQ, file = "../data/squirrels/CV_KRQ_adaptive.RData")
