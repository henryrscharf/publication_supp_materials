## prep variables ----
source("squirrels/adaptive/prep.R")
## make storage variables + loop over adaptive prior ----
CV_SPL <- matrix(NA, k, length(scales))
rownames(CV_SPL) <- 1:k
colnames(CV_SPL) <- scales
SPLconst_scaled <- SPLconstants
for(scale in scales){
  message("scale = ", scale, "\n",
          "time = ", Sys.time())
  scale_ind <- which(scale == scales)
  ## constants ----
  SPLconst_scaled$var_beta <- scale * SPLconstants$var_beta
  SPLconst_scaled$var_alpha <- scale * SPLconstants$var_alpha
  ## create our spatial model object [SPL] ----
  SPLmodel <- nimbleModel(code = SPcode, constants = SPLconst_scaled,
                          data = Ldata, inits = SPLinits)
  SPLmcmcConf <- configureMCMC(SPLmodel)
  SPLmcmc <- buildMCMC(SPLmcmcConf)
  ## k-fold CV ----
  system.time({
    CV_SPL[, scale_ind] <-
      my_runCrossValidate(MCMCconfiguration = SPLmcmcConf, nCores = n_cores, folds_list = folds_list,
                          MCMCcontrol = list(niter = N_iterations, nburnin = N_iterations / 2))
  })
}
## ----
## save scores ----
save(CV_SPL, file = "../data/squirrels/CV_SPL_adaptive.RData")
