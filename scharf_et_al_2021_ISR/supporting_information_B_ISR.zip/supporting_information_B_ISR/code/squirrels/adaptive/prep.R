################# ----
## PRELIMINARY ## ----
################# ----
## libraries ----
library(nimble); library(Matrix); library(raster)
library(foreach); library(iterators); library(doParallel)
nimbleOptions(check = FALSE, clearNimbleFunctionsAfterCompiling = FALSE)
## squirrel data ----
squirrels <- read.table(file = "../data/squirrels/SwissSquirrels.txt", header = T)
N <- nrow(squirrels)
J <- 3
## folds for CV + adaptive scales + N_iterations ----
set.seed(2017)
k <- 8
scales <- c(0.1, 0.5, 1, 2, 5, 10, 20, 100)
n_cores <- 1
N_iterations <- 5e4
y_vec <- as.matrix(squirrels[, grep('det', colnames(squirrels))])
## observation-wise CV ----
# folds_ind <- sample(which(!is.na(y_vec)), sum(!is.na(y_vec)))
# folds_list <- apply(matrix(c(folds_ind, rep(NA, k - (length(folds_ind) %% k))), ncol = k, byrow = T), 2, sort)
## site-wise CV ----
row_folds <- matrix(c(sample(1:N, N), rep(NA, k - N %%k)), ncol = k, byrow = T)
ind_mat <- matrix(1:(N * J), N, J)
ind_mat[is.na(y_vec)] <- NA
folds_list <- apply(row_folds, 2, function(x) sort(c(ind_mat[x, ])))
sapply(folds_list, length)
## my runCrossValidate function ----
my_runCrossValidate <- function(MCMCconfiguration, folds_list,
                                lossFunction = function(simulatedDataValues, actualDataValues){
                                  (simulatedDataValues - actualDataValues)^2
                                },
                                MCMCcontrol = list(niter = 1e2, nburnin = 5e1), nCores = 1){
  require(foreach); require(iterators)
  out <- foreach(fold = iter(folds_list), .combine = "c", .packages = c('nimble')) %do% {
    ## drop fold ----
    model <- MCMCconfiguration$model
    data_fold_dropped <- model$origData
    test_y <- as.numeric(data_fold_dropped$y[fold])
    data_fold_dropped$y[fold] <- NA
    model$setData(data_fold_dropped)
    MCMCconfiguration <- configureMCMC(model)
    MCMCconfiguration$addMonitors2('p')
    mcmc <- buildMCMC(MCMCconfiguration)
    ## compile ----
    Cmodel <- compileNimble(model)
    Cmcmc <- compileNimble(mcmc, project = Cmodel)
    ## N_iterations + fit ----
    Cmcmc$run(MCMCcontrol[["niter"]], nburnin = MCMCcontrol[["nburnin"]])
    samples2 <- as.matrix(Cmcmc$mvSamples2)
    ## compute loss ----
    loss <- as.numeric(mean(lossFunction(t(samples2[, grep('p', colnames(samples2))[fold]]), test_y)))
    ## put data back (for parallelization purposes)
    data_fold_dropped$y[fold] <- test_y
    model$setData(data_fold_dropped)
    return(loss)
  }
  return(out)
}
## nimble model code[N, P, KR, SP] ----
source("squirrels/nimble_models.R")
## data lists [N, L, Q] ----
source("squirrels/nimble_data_lists.R")
