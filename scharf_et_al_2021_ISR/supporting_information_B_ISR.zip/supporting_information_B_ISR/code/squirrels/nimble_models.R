## define the naive model [N] ----
Ncode <- nimbleCode({
  r ~ dbeta(a_r, b_r)
  psi ~ dbeta(a_psi, b_psi)
  for(i in 1:N){
    z[i] ~ dbern(psi)
    for(j in 1:J){
      p[i, j] <- r * z[i]
      y[i, j] ~ dbern(p[i, j])
    }
  }
})
## define the Poisson model [P] ----
Pcode <- nimbleCode({
  mu_beta[1:p_beta] <- rep(0, p_beta)
  Q_beta[1:p_beta, 1:p_beta] <- diag(p_beta) / var_beta
  mu_alpha[1:p_alpha] <- rep(0, p_alpha)
  Q_alpha[1:p_alpha, 1:p_alpha] <- diag(p_alpha) / var_alpha
  beta[1:p_beta] ~ dmnorm(mu_beta[1:p_beta], Q_beta[1:p_beta, 1:p_beta])
  alpha[1:p_alpha] ~ dmnorm(mu_alpha[1:p_alpha], Q_alpha[1:p_alpha, 1:p_alpha])
  lambda[1:N] <- exp(X_beta[1:N, 1:p_beta] %*% beta[1:p_beta])
  for(i in 1:N){
    for(j in 1:J){
      probit(r[i, j]) <- inprod(X_alpha[i, j, 1:p_alpha], alpha[1:p_alpha])
      p[i, j] <- r[i, j] * (1 - exp(-lambda[i]))
      y[i, j] ~ dbern(p[i, j])
    }
  }
})
## define Kery & Royle model [KR] ----
KRcode <- nimbleCode({
  mu_beta[1:p_beta] <- rep(0, p_beta)
  Q_beta[1:p_beta, 1:p_beta] <- diag(p_beta) / var_beta
  mu_alpha[1:p_alpha] <- rep(0, p_alpha)
  Q_alpha[1:p_alpha, 1:p_alpha] <- diag(p_alpha) / var_alpha
  beta[1:p_beta] ~ dmnorm(mu_beta[1:p_beta], Q_beta[1:p_beta, 1:p_beta])
  alpha[1:p_alpha] ~ dmnorm(mu_alpha[1:p_alpha], Q_alpha[1:p_alpha, 1:p_alpha])
  for(i in 1:N){
    logit(psi[i]) <- inprod(X_beta[i, ], beta[1:p_beta])
    for(j in 1:J){
      logit(r[i, j]) <- inprod(X_alpha[i, j, ], alpha[1:p_alpha])
      p[i, j] <- r[i, j] * psi[i]
      y[i, j] ~ dbern(p[i, j])
    }
  }
})
## define the spatial model [SP] ----
SPcode <- nimbleCode({
  mu_beta[1:p_beta] <- rep(0, p_beta)
  Q_beta[1:p_beta, 1:p_beta] <- diag(p_beta) / var_beta
  mu_alpha[1:p_alpha] <- rep(0, p_alpha)
  Q_alpha[1:p_alpha, 1:p_alpha] <- diag(p_alpha) / var_alpha
  beta[1:p_beta] ~ dmnorm(mu_beta[1:p_beta], Q_beta[1:p_beta, 1:p_beta])
  alpha[1:p_alpha] ~ dmnorm(mu_alpha[1:p_alpha], Q_alpha[1:p_alpha, 1:p_alpha])
  eta[1:N] ~ dcar_normal(adj = adj[1:edges], num = num[1:N], tau = tau)
  tau ~ dinvgamma(a_tau, b_tau)
  lambda[1:N] <- exp(X_beta[1:N, 1:p_beta] %*% beta[1:p_beta] + eta[1:N])
  for(i in 1:N){
    for(j in 1:J){
      probit(r[i, j]) <- inprod(X_alpha[i, j, 1:p_alpha], alpha[1:p_alpha])
      p[i, j] <- r[i, j] * (1 - exp(-lambda[i]))
      y[i, j] ~ dbern(p[i, j])
    }
  }
})
