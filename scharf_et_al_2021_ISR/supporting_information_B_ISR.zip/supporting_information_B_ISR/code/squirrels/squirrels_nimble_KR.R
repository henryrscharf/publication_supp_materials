################# ----
## PRELIMINARY ## ----
################# ----
## libraries ----
library(nimble); library(Matrix); library(raster)
## squirrel data ----
squirrels <- read.table(file = "../data/squirrels/SwissSquirrels.txt", header = T)
N <- nrow(squirrels)
J <- 3
## nimble model code[N, P, KR, SP] ----
source("squirrels/nimble_models.R")
## data lists [N, L, Q] ----
source("squirrels/nimble_data_lists.R")
## create model objects [KRL\Q] ----
Lconst_scaled <- Lconstants
Lconst_scaled$var_beta <- 0.5 * Lconstants$var_beta
Lconst_scaled$var_alpha <- 0.5 * Lconstants$var_alpha
Qconst_scaled <- Qconstants
Qconst_scaled$var_beta <- 0.5 * Qconstants$var_beta
Qconst_scaled$var_alpha <- 0.5 * Qconstants$var_alpha
KRLmodel <- nimbleModel(code = KRcode, constants = Lconst_scaled,
                        data = Ldata, inits = Linits, check = T)
KRLmcmcConf <- configureMCMC(KRLmodel)
KRLmcmcConf$addMonitors2('p')
KRLmcmc <- buildMCMC(KRLmcmcConf)
##
KRQmodel <- nimbleModel(code = KRcode, constants = Qconst_scaled,
                        data = Qdata, inits = Qinits, check = T)
KRQmcmcConf <- configureMCMC(KRQmodel)
KRQmcmcConf$addMonitors2('p')
KRQmcmc <- buildMCMC(KRQmcmcConf)
## compile objects [KRL\Q] ----
CKRLmodel <- compileNimble(KRLmodel)
CKRLmcmc <- compileNimble(KRLmcmc, project = KRLmodel)
##
CKRQmodel <- compileNimble(KRQmodel)
CKRQmcmc <- compileNimble(KRQmcmc, project = KRQmodel)
## N_iterations + fit ----
N_iterations <- 5e4
CKRLmcmc$run(N_iterations, nburnin = N_iterations / 2)
KRLsamples <- as.matrix(CKRLmcmc$mvSamples)
KRLsamples_transformed <- KRLsamples %*% Matrix::bdiag(t(L_A_alpha), t(L_A_beta))
KRLsamples2 <- as.matrix(CKRLmcmc$mvSamples2)
colnames(KRLsamples_transformed) <- colnames(KRLsamples)
##
CKRQmcmc$run(N_iterations, nburnin = N_iterations / 2)
KRQsamples <- as.matrix(CKRQmcmc$mvSamples)
KRQsamples_transformed <- KRQsamples %*% t(Matrix::bdiag(Q_A_alpha, Q_A_beta))
KRQsamples2 <- as.matrix(CKRQmcmc$mvSamples2)
colnames(KRQsamples_transformed) <- colnames(KRQsamples)
## save chains ----
save(KRLsamples_transformed, KRLsamples, KRLsamples2,
     KRQsamples_transformed, KRQsamples, KRQsamples2, file = "../data/squirrels/KR_fit.RData")
## load chains ----
load(file = "../data/squirrels/KR_fit.RData")
## ----
## device ----
pdf(file = "../fig/squirrels_diagnostics_KR.pdf", width = 8, height = 7)
## plot traces [KRL] ----
used_iterations <- seq(N_iterations / 2 + 1, N_iterations, 1)
layout(matrix(1:2, 2, 1))
matplot(used_iterations, KRLsamples[, grep('beta', colnames(KRLsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(beta[svd]), xlab = "")
abline(h = 0, lty = 2)
matplot(used_iterations, KRLsamples[, grep('alpha', colnames(KRLsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(alpha[svd]), xlab = "")
abline(h = 0, lty = 2)
## plot traces [KRQ] ----
used_iterations <- seq(N_iterations / 2 + 1, N_iterations, 1)
layout(matrix(1:2, 2, 1))
matplot(used_iterations, KRQsamples[, grep('beta', colnames(KRQsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(beta[svd]), xlab = "")
abline(h = 0, lty = 2)
matplot(used_iterations, KRQsamples[, grep('alpha', colnames(KRQsamples))],
        type = "l", lty = 1, bty = "n", ylab = expression(alpha[svd]), xlab = "")
abline(h = 0, lty = 2)
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_effects_KRL.pdf", width = 8, height = 7)
## calc effects [KRL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- X_elevation %*% t(KRLsamples_transformed[, grep('beta', colnames(KRLsamples_transformed))])
pr_elevation <- t(apply(1 / (1 + exp(-lambda_elevation_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- X_forest %*% t(KRLsamples_transformed[, grep('beta', colnames(KRLsamples_transformed))])
pr_forest <- t(apply(1 / (1 + exp(-lambda_forest_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
logit_pr_date_iter <- X_date %*% t(KRLsamples_transformed[, grep('alpha', colnames(KRLsamples_transformed))])
pr_date <- t(apply(1 / (1 + exp(-logit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
logit_pr_duration_iter <- X_duration %*% t(KRLsamples_transformed[, grep('alpha', colnames(KRLsamples_transformed))])
pr_duration <- t(apply(1 / (1 + exp(-logit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## plot effects [KRL] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values, pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1, las = 1,
        ylab = "Pred. occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values, pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1,
        ylab = "Pred. occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values, pr_date, type = "l", lty = 1, col = line_colors,
        lwd = lwds, ylim = 0:1,
        ylab = "Pred. detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values, pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1,
        ylab = "Pred. detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curves - KRL", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_grad_effects_KRL.pdf", width = 8, height = 7)
## calc grad effects [KRL] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value)
lambda_elevation_iter <- X_elevation %*% t(KRLsamples_transformed[, grep('beta', colnames(KRLsamples_transformed))])
pr_elevation_iter <- 1 / (1 + exp(-lambda_elevation_iter))
grad_pr_elevation <- t(apply(apply(pr_elevation_iter, 2, diff),
  1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(elev_values)
# grad_pr_elevation <- t(apply(t(exp(-lambda_forest_iter) / (1 + exp(-lambda_elevation_iter))^2) *
#                                (KRLsamples_transformed[, grep('beta\\[2\\]', colnames(KRLsamples_transformed))] +
#                                   forest_value * KRLsamples_transformed[, grep('beta\\[4\\]', colnames(KRLsamples_transformed))]),
#                              2, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values)
lambda_forest_iter <- exp(X_forest %*% t(KRLsamples_transformed[, grep('beta', colnames(KRLsamples_transformed))]))
pr_forest_iter <- 1 / (1 + exp(-lambda_forest_iter))
grad_pr_forest <- t(apply(apply(pr_forest_iter, 2, diff),
                          1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(forest_values)
# grad_pr_forest <- t(apply(
#   t(exp(-lambda_forest_iter) * lambda_forest_iter) *
#     (KRLsamples_transformed[, grep('beta\\[3\\]', colnames(KRLsamples_transformed))] +
#        elev_value * KRLsamples_transformed[, grep('beta\\[4\\]', colnames(KRLsamples_transformed))]),
#   2, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value)
logit_pr_date_iter <- X_date %*% t(KRLsamples_transformed[, grep('alpha', colnames(KRLsamples_transformed))])
pr_date_iter <- 1 / (1 + exp(-logit_pr_date_iter))
grad_pr_date <- t(apply(apply(pr_date_iter, 2, diff),
                        1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(date_values)
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values)
logit_pr_duration_iter <- X_duration %*% t(KRLsamples_transformed[, grep('alpha', colnames(KRLsamples_transformed))])
pr_duration_iter <- 1 / (1 + exp(-logit_pr_duration_iter))
grad_pr_duration <- t(apply(apply(pr_duration_iter, 2, diff),
                            1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(dur_values)
## plot grad effects [KRL] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values[-1], 1e2 * grad_pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values[-1], 10 * grad_pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values[-1], 14 * grad_pr_date, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values[-1], 60 * grad_pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curve gradients - KRL", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_effects_KRQ.pdf", width = 8, height = 7)
## calc effects [KRQ] ----
## beta
elev_values <- seq(min(elev), max(elev), l = 1e2)
forest_value <- mean(forest)
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- X_elevation %*% t(KRQsamples_transformed[, grep('beta', colnames(KRQsamples_transformed))])
pr_elevation <- t(apply(1 / (1 + exp(-lambda_elevation_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- X_forest %*% t(KRQsamples_transformed[, grep('beta', colnames(KRQsamples_transformed))])
pr_forest <- t(apply(1 / (1 + exp(-lambda_forest_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
logit_pr_date_iter <- X_date %*% t(KRQsamples_transformed[, grep('alpha', colnames(KRQsamples_transformed))])
pr_date <- t(apply(1 / (1 + exp(-logit_pr_date_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
logit_pr_duration_iter <- X_duration %*% t(KRQsamples_transformed[, grep('alpha', colnames(KRQsamples_transformed))])
pr_duration <- t(apply(1 / (1 + exp(-logit_pr_duration_iter)), 1, quantile, probs = c(0.025, 0.5, 0.975)))
## plot effects [KRQ] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values, pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1, las = 1,
        ylab = "Pred. occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values, pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1,
        ylab = "Pred. occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values, pr_date, type = "l", lty = 1, col = line_colors,
        lwd = lwds, ylim = 0:1,
        ylab = "Pred. detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values, pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, ylim = 0:1,
        ylab = "Pred. detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curves - KRQ", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
## device ----
pdf(file = "../fig/squirrels_grad_effects_KRQ.pdf", width = 8, height = 7)
## calc grad effects [KRQ] ----
## beta
X_elevation <- cbind(1, elev_values, forest_value, elev_values^2, forest_value^2,
                     elev_values * forest_value, elev_values^2 * forest_value,
                     elev_values * forest_value^2)
lambda_elevation_iter <- X_elevation %*% t(KRQsamples_transformed[, grep('beta', colnames(KRQsamples_transformed))])
pr_elevation_iter <- 1 / (1 + exp(-lambda_elevation_iter))
grad_pr_elevation <- t(apply(apply(pr_elevation_iter, 2, diff),
                             1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(elev_values)
# grad_pr_elevation <- t(apply(t(exp(-lambda_forest_iter) / (1 + exp(-lambda_elevation_iter))^2) *
#                                (KRQsamples_transformed[, grep('beta\\[2\\]', colnames(KRQsamples_transformed))] +
#                                   forest_value * KRQsamples_transformed[, grep('beta\\[4\\]', colnames(KRQsamples_transformed))]),
#                              2, quantile, probs = c(0.025, 0.5, 0.975)))
##
elev_value <- mean(elev)
forest_values <- seq(min(forest), max(forest), l = 1e2)
X_forest <- cbind(1, elev_value, forest_values, elev_value^2, forest_values^2,
                  elev_value * forest_values, elev_value^2 * forest_values,
                  elev_value * forest_values^2)
lambda_forest_iter <- X_forest %*% t(KRQsamples_transformed[, grep('beta', colnames(KRQsamples_transformed))])
pr_forest_iter <- 1 / (1 + exp(-lambda_forest_iter))
grad_pr_forest <- t(apply(apply(pr_forest_iter, 2, diff),
                          1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(forest_values)
# grad_pr_forest <- t(apply(
#   t(exp(-lambda_forest_iter) * lambda_forest_iter) *
#     (KRQsamples_transformed[, grep('beta\\[3\\]', colnames(KRQsamples_transformed))] +
#        elev_value * KRQsamples_transformed[, grep('beta\\[4\\]', colnames(KRQsamples_transformed))]),
#   2, quantile, probs = c(0.025, 0.5, 0.975)))
## alpha
date_values <- seq(min(date), max(date), by = 1)
dur_value <- mean(dur)
X_date <- cbind(1, date_values, dur_value, dur_value^2)
logit_pr_date_iter <- X_date %*% t(KRQsamples_transformed[, grep('alpha', colnames(KRQsamples_transformed))])
pr_date_iter <- 1 / (1 + exp(-logit_pr_date_iter))
grad_pr_date <- t(apply(apply(pr_date_iter, 2, diff),
                        1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(date_values)
##
dur_values <- seq(min(squirrels[, grep('dur', colnames(squirrels))], na.rm = T),
                  max(squirrels[, grep('dur', colnames(squirrels))], na.rm = T), l = 1e2)
date_value <- mean(date)
X_duration <- cbind(1, date_value, dur_values, dur_values^2)
logit_pr_duration_iter <- X_duration %*% t(KRQsamples_transformed[, grep('alpha', colnames(KRQsamples_transformed))])
pr_duration_iter <- 1 / (1 + exp(-logit_pr_duration_iter))
grad_pr_duration <- t(apply(apply(pr_duration_iter, 2, diff),
                            1, quantile, probs = c(0.025, 0.5, 0.975))) / diff(dur_values)
## plot grad effects [KRQ] ----
layout(matrix(1:4, 2, 2, byrow = T))
line_colors <- c('gray', 'blue', 'gray'); lwds <- c(1, 3, 1)
matplot(elev_values[-1], 1e2 * grad_pr_elevation, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Elevation (m)", bty = "n")
matplot(forest_values[-1], 10 * grad_pr_forest, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in occupancy prob.", xlab = "Forest cover (%)", bty = "n")
matplot(date_values[-1], 14 * grad_pr_date, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Date (1 = 1 April)", bty = "n")
matplot(dur_values[-1], 60 * grad_pr_duration, type = "l", lty = 1,
        col = line_colors, lwd = lwds, las = 1,
        ylab = "Change in detection prob.", xlab = "Survey duration (min)", bty = "n")
title(main = "Probability curve gradients - KRQ", outer = T, line = -1)
## dev.off ----
dev.off()
## ----
## ESS ----
coda::effectiveSize(coda::mcmc(KRLsamples[, grep('alpha|beta', colnames(KRLsamples))]))
coda::effectiveSize(coda::mcmc(KRQsamples[, grep('alpha|beta', colnames(KRQsamples))]))
## ----
## maps ----
load(file = "../data/squirrels/Switzerland.RData")
blocks <- matrix(1:nrow(Switzerland), ncol = 5)
## predict at each location [KRL] (~1min) ----
KRL_pr_Switzerland <- NULL
system.time({
  for(b in 1:ncol(blocks)){
    X_Switzerland <- as.matrix(cbind(1, Switzerland[blocks[, b], c('elevation', 'forest')]))
    lambda_Switzerland_iter <- X_Switzerland %*% t(KRLsamples_transformed[, 4:6])
    KRL_pr_Switzerland <-
      rbind(KRL_pr_Switzerland, t(apply(1 / (1 + exp(-lambda_Switzerland_iter)), 1,
                                        quantile, probs = c(0.025, 0.5, 0.975))))
    rm(lambda_Switzerland_iter)
    gc()
  }
})
## device ----
pdf("../fig/squirrels_map_KRL.pdf")
## rasterize + plot [KRL] ----
KRL_pr_raster <- rasterFromXYZ(xyz = cbind(Switzerland[, c('x', 'y')], KRL_pr_Switzerland))
elev <- rasterFromXYZ(Switzerland[, c('x', 'y', 'elevation')])
elev[elev > 2250] <- NA
KRL_pr_raster <- mask(KRL_pr_raster, elev)
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
plot(KRL_pr_raster[[2]], col = colorRampPalette(c("grey", "yellow", "orange", "red"))(1e2),
     box = F, axes = F, zlim = 0:1, main = 'KRL')
plot(water_raster > 0, add = T, col = "lightblue", legend = F)
## dev.off ----
dev.off()
## predict at each location [KRQ] (~1min) ----
KRQ_pr_Switzerland <- NULL
system.time({
  for(b in 1:ncol(blocks)){
    X_Switzerland <- as.matrix(cbind(1, Switzerland[blocks[, b], c('elevation', 'forest')],
                                     Switzerland[blocks[, b], c('elevation', 'forest')]^2,
                                     Switzerland[blocks[, b], 'elevation'] *
                                       Switzerland[blocks[, b], 'forest'],
                                     Switzerland[blocks[, b], 'elevation']^2 *
                                       Switzerland[blocks[, b], 'forest'],
                                     Switzerland[blocks[, b], 'elevation'] *
                                       Switzerland[blocks[, b], 'forest']^2))
    lambda_Switzerland_iter <- X_Switzerland %*% t(KRQsamples_transformed[, 5:12])
    KRQ_pr_Switzerland <-
      rbind(KRQ_pr_Switzerland, t(apply(1 / (1 + exp(-lambda_Switzerland_iter)), 1,
                                        quantile, probs = c(0.025, 0.5, 0.975))))
    rm(lambda_Switzerland_iter)
    gc()
  }
})
## device ----
pdf("../fig/squirrels_map_KRQ.pdf")
## rasterize + plot [KRQ] ----
KRQ_pr_raster <- rasterFromXYZ(xyz = cbind(Switzerland[, c('x', 'y')], KRQ_pr_Switzerland))
elev <- rasterFromXYZ(Switzerland[, c('x', 'y', 'elevation')])
elev[elev > 2250] <- NA
KRQ_pr_raster <- mask(KRQ_pr_raster, elev)
water_raster <- rasterFromXYZ(Switzerland[, c('x', 'y', 'water')])
water_raster[water_raster < 4] <- NA
plot(KRQ_pr_raster[[2]], col = colorRampPalette(c("grey", "yellow", "orange", "red"))(1e2),
     box = F, axes = F, zlim = 0:1, main = 'KRQ')
plot(water_raster > 0, add = T, col = "lightblue", legend = F)
## dev.off ----
dev.off()
