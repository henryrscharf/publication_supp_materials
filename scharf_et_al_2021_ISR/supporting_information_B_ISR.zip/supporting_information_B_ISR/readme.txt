The scripts in this collection can be used to reproduce the analysis in "Constructing flexible, identifiable, and interpretable statistical models for binary data" by Scharf et al.

- scripts in equivalent_auxiliary_variables/ reproduce Figures 1--3
- squirrels/plot_covariates.R reproduces Figure 1 in Supporting Information A
- squirrels/plots_model_compatre.R reproduces Figure 4 in main text and Figure 4 in Supporting Information A
- squirrels/squirrels_nimble_KR.R reproduce the results of Kéry and Royle (2015) [KR(L/Q)]
- squirrels/squirrels_nimble_poisson.R fits the Poisson models [P(L/Q); Figure 5]
- squirrels/squirrels_nimble_spatial_CAR.R fits the spatial ICAR models [SP(L/Q); Figure 6]
- squirrels/adaptive/ scripts in this directory performs the cross-validation procedure [Figure 2 and 3 in Supporting Information A]
